#!/bin/sh
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  printf '%s\n' 'Node.js 18 or newer is required on the host computer.'
  exit 1
fi
node server.js

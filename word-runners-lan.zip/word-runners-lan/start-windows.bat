@echo off
title Word Runners - local Wi-Fi host
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18 or newer is required on the host computer.
  echo Install it, then launch this file again.
  pause
  exit /b 1
)
node server.js
echo.
echo The game server stopped.
pause

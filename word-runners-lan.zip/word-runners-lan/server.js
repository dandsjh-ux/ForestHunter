import http from 'node:http';
import os from 'node:os';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {randomBytes} from 'node:crypto';
import {WebSocketServer, WebSocket} from 'ws';
import {createRoom, addPlayer, removeLobbyPlayer, startMatch, setInput, tickRoom, snapshot, MAX_PLAYERS, POWERUP_FREQUENCIES, TURN_SECONDS, validateWordSets} from './game.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(here, 'public');
const files = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/index.html', ['index.html', 'text/html; charset=utf-8']],
  ['/style.css', ['style.css', 'text/css; charset=utf-8']],
  ['/game.js', ['game.js', 'text/javascript; charset=utf-8']],
  ['/favicon.svg', ['favicon.svg', 'image/svg+xml']]
]);
const alphabet = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';

function networkUrls(port) {
  const addresses = new Set();
  let interfacesByName;
  try { interfacesByName = os.networkInterfaces(); }
  catch { return []; } // Some restricted runtimes do not expose network adapters.
  for (const interfaces of Object.values(interfacesByName)) {
    for (const item of interfaces || []) {
      if (item.family === 'IPv4' && !item.internal) addresses.add(`http://${item.address}:${port}`);
    }
  }
  return [...addresses];
}

export function createAppServer() {
  validateWordSets();
  const rooms = new Map();
  const wss = new WebSocketServer({noServer: true, maxPayload: 2048});
  let port = 0;
  let timer;
  let lastBroadcast = 0;

  const send = (ws, data) => {
    if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
  };
  const broadcast = (room, data) => {
    for (const p of room.players.values()) send(p.socket, data);
  };
  const stateToAll = room => {
    const now = Date.now();
    for (const p of room.players.values()) send(p.socket, snapshot(room, now, p.id));
  };
  const error = (ws, message) => send(ws, {type: 'error', message});

  function code() {
    let result;
    do {
      result = [...randomBytes(5)].map(n => alphabet[n % alphabet.length]).join('');
    } while (rooms.has(result));
    return result;
  }

  function detach(ws, explicit = false) {
    if (!ws.roomCode || !ws.playerId) return;
    const room = rooms.get(ws.roomCode);
    const p = room?.players.get(ws.playerId);
    ws.roomCode = null; ws.playerId = null;
    if (!room || !p || p.socket !== ws) return;
    p.socket = null; p.connected = false; p.input = {x: 0, z: 0, dash: false};
    p.disconnectedAt = Date.now();
    if (explicit && room.phase === 'lobby') removeLobbyPlayer(room, p.id);
    if (room.hostId === p.id) {
      room.hostId = room.order.find(playerId => room.players.get(playerId)?.connected) ?? p.id;
    }
    room.lastActivity = Date.now();
    stateToAll(room);
  }

  function attach(ws, room, p) {
    if (ws.roomCode) detach(ws, true);
    if (p.socket && p.socket !== ws) p.socket.close(4000, 'Reconnected elsewhere');
    p.socket = ws; p.connected = true; p.disconnectedAt = 0;
    ws.roomCode = room.code; ws.playerId = p.id;
    room.lastActivity = Date.now();
    if (!room.players.get(room.hostId)?.connected) room.hostId = p.id;
    send(ws, {type: 'joined', code: room.code, playerId: p.id, token: p.token});
    stateToAll(room);
  }

  const httpServer = http.createServer(async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    const url = new URL(req.url, 'http://localhost');
    if (req.method !== 'GET') { res.writeHead(405).end(); return; }
    if (url.pathname === '/api/meta') {
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({urls: networkUrls(port), port}));
      return;
    }
    if (url.pathname === '/api/rooms') {
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({rooms: [...rooms.values()]
        .filter(r => r.phase === 'lobby' && r.order.length < MAX_PLAYERS)
        .map(r => ({code: r.code, name: r.name, players: r.order.filter(id => r.players.get(id)?.connected).length,
          maxPlayers: MAX_PLAYERS}))}));
      return;
    }
    const file = files.get(url.pathname);
    if (!file) { res.writeHead(404).end('Not found'); return; }
    try {
      const body = await readFile(path.join(publicDir, file[0]));
      res.setHeader('Content-Type', file[1]);
      res.setHeader('Cache-Control', 'no-cache');
      res.end(body);
    } catch {
      res.writeHead(500).end('Game files unavailable. Run npm run build.');
    }
  });

  httpServer.on('upgrade', (req, socket, head) => {
    if (new URL(req.url, 'http://localhost').pathname !== '/socket') { socket.destroy(); return; }
    wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws));
  });

  wss.on('connection', ws => {
    ws.on('message', raw => {
      let msg;
      try { msg = JSON.parse(raw.toString()); } catch { error(ws, 'Invalid message.'); return; }
      try {
        if (msg.type === 'create') {
          const {room, host} = createRoom(code(), msg.name);
          rooms.set(room.code, room);
          attach(ws, room, host);
          return;
        }
        if (msg.type === 'join') {
          const room = rooms.get(String(msg.code ?? '').toUpperCase().trim());
          if (!room) throw new Error('Room not found. Check the code and host address.');
          let p = [...room.players.values()].find(player => player.token === msg.token);
          if (!p) p = addPlayer(room, msg.name);
          attach(ws, room, p);
          return;
        }
        const room = rooms.get(ws.roomCode);
        const p = room?.players.get(ws.playerId);
        if (!room || !p) throw new Error('Join a room first.');
        room.lastActivity = Date.now();
        if (msg.type === 'input') {
          if (room.phase === 'playing') setInput(p, msg);
        } else if (msg.type === 'settings') {
          if (room.hostId !== p.id || room.phase !== 'lobby') throw new Error('Only the host can change lobby settings.');
          const next = {};
          if (msg.cycles !== undefined) {
            if (![1, 2, 3, 4].includes(msg.cycles)) throw new Error('Choose between one and four hunter turns per player.');
            next.cycles = msg.cycles;
          }
          if (msg.turnSeconds !== undefined) {
            if (!TURN_SECONDS.includes(msg.turnSeconds)) throw new Error('Choose a hunter turn length from the list.');
            next.turnSeconds = msg.turnSeconds;
          }
          if (msg.powerupFrequency !== undefined) {
            if (!Object.hasOwn(POWERUP_FREQUENCIES, msg.powerupFrequency)) throw new Error('Choose a powerup frequency from the list.');
            next.powerupFrequency = msg.powerupFrequency;
          }
          if (!Object.keys(next).length) throw new Error('Choose a setting to change.');
          Object.assign(room, next);
          stateToAll(room);
        } else if (msg.type === 'start' || msg.type === 'playAgain') {
          if (room.hostId !== p.id) throw new Error('Only the host can start a match.');
          startMatch(room);
          stateToAll(room);
        } else if (msg.type === 'leave') {
          detach(ws, true);
          send(ws, {type: 'left'});
        }
      } catch (e) { error(ws, e.message || 'Something went wrong.'); }
    });
    ws.on('close', () => detach(ws));
    ws.on('error', () => {});
  });

  function update() {
    const now = Date.now();
    for (const [roomCode, room] of rooms) {
      if (room.phase === 'lobby') {
        for (const p of [...room.players.values()]) {
          if (!p.connected && now - p.disconnectedAt > 60_000) removeLobbyPlayer(room, p.id);
        }
      }
      if (!room.order.length || ([...room.players.values()].every(p => !p.connected) && now - room.lastActivity > 90_000)) {
        rooms.delete(roomCode); continue;
      }
      tickRoom(room, now);
      for (const event of room.events.splice(0)) {
        const message = {type: 'event', eventType: event.type, text: event.text};
        if (event.playerId) send(room.players.get(event.playerId)?.socket, message);
        else broadcast(room, message);
      }
      if (now - lastBroadcast >= 100 && room.phase !== 'lobby') stateToAll(room);
    }
    if (now - lastBroadcast >= 100) lastBroadcast = now;
  }

  return {
    rooms,
    async listen(requestedPort = 3000) {
      await new Promise((resolve, reject) => {
        httpServer.once('error', reject);
        httpServer.listen(requestedPort, '0.0.0.0', resolve);
      });
      port = httpServer.address().port;
      timer = setInterval(update, 50);
      return {port, urls: networkUrls(port)};
    },
    async close() {
      clearInterval(timer);
      for (const ws of wss.clients) ws.terminate();
      await new Promise(resolve => httpServer.close(resolve));
    }
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const app = createAppServer();
  app.listen(Number(process.env.PORT) || 3000).then(({port, urls}) => {
    console.log(`\nWORD RUNNERS is ready on this computer: http://localhost:${port}`);
    console.log('On the same Wi-Fi, open one of these addresses:');
    for (const url of urls) console.log(`  ${url}`);
    console.log('Keep this window open while you play. Press Ctrl+C to stop.\n');
  }).catch(err => { console.error(err); process.exitCode = 1; });
}

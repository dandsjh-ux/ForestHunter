import * as THREE from 'three';
import QRCode from 'qrcode';
import {ALL_TREES, HIDING_SPOTS, HIDE_PROPS, SHRUBS, WORLD_HALF} from '../shared/map.js';

const $ = id => document.getElementById(id);
const ui = Object.fromEntries([
  'gameCanvas','menu','welcomePanel','lobbyPanel','resultPanel','lobbyInstructions','nameInput','codeInput','searchInput',
  'roomList','connectionStatus','createBtn','joinBtn','lobbyCode','copyCodeBtn','addressList',
  'copyLinkBtn','qrImage','playerCount','hostBadge','lobbyPlayers','hostSettings','cyclesSelect',
  'turnLengthSelect','powerupFrequencySelect','powerupHint','roundSummary',
  'startBtn','waitingText','leaveLobbyBtn','winnerTitle','finalScores','againBtn','againWait',
  'leaveResultsBtn','hud','roundLabel','roleLabel','ruleTitle','ruleHint','timer','timerLabel',
  'liveScores','objective','phaseBanner','toast','soundBtn','leaveGameBtn','revealTracker','revealCountdown','revealTargets','joystick','stick',
  'dashBtn','dashCooldown','boostStatus'
].map(id => [id, $(id)]));

let socket, game = null, playerId = null, roomCode = null, roomToken = null;
let meta = {urls: []}, roomList = [], chosenAddress = '', lastLobbySignature = '';
let stateAt = performance.now(), toastUntil = 0, soundOn = true, audioContext = null;
const keys = new Set();
const joystick = {x: 0, z: 0, pointer: null};
let dashHeld = false;
const playerMeshes = new Map(), wordMeshes = new Map(), powerupMeshes = new Map();

ui.nameInput.value = localStorage.getItem('word-runners-name') || '';
const codeParam = new URLSearchParams(location.search).get('room')?.toUpperCase() || '';
ui.codeInput.value = codeParam.slice(0, 5);
if (codeParam) {
  const remembered = JSON.parse(localStorage.getItem(`word-runners-session-${codeParam}`) || 'null');
  if (remembered?.token) { roomCode = codeParam; roomToken = remembered.token; }
}

function showPanel(panel) {
  ui.menu.classList.remove('hidden');
  for (const p of [ui.welcomePanel, ui.lobbyPanel, ui.resultPanel]) p.classList.toggle('hidden', p !== panel);
  ui.hud.classList.add('hidden');
  document.querySelector('.grain').style.display = '';
}
function showGame() {
  ui.menu.classList.add('hidden');
  ui.hud.classList.remove('hidden');
  document.querySelector('.grain').style.display = 'none';
}
function send(data) { if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify(data)); }
function status(message, bad = false) {
  ui.connectionStatus.textContent = message;
  ui.connectionStatus.classList.toggle('error', bad);
  ui.createBtn.disabled = bad; ui.joinBtn.disabled = bad;
}
function connect() {
  status('Connecting to the game server…');
  const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
  socket = new WebSocket(`${protocol}//${location.host}/socket`);
  socket.addEventListener('open', () => {
    status('Connected · Open this same game link on every device.');
    if (roomCode && roomToken) send({type: 'join', code: roomCode, token: roomToken, name: ui.nameInput.value});
    refreshRooms();
  });
  socket.addEventListener('message', event => {
    let msg;
    try { msg = JSON.parse(event.data); } catch { return; }
    if (msg.type === 'error') {
      notify(msg.message, true);
      if (roomCode && !game) { roomCode = null; roomToken = null; showPanel(ui.welcomePanel); }
    } else if (msg.type === 'joined') {
      roomCode = msg.code; roomToken = msg.token; playerId = msg.playerId;
      localStorage.setItem(`word-runners-session-${roomCode}`, JSON.stringify({token: roomToken}));
      history.replaceState(null, '', `?room=${roomCode}`);
      chosenAddress = '';
      lastLobbySignature = '';
    } else if (msg.type === 'state') {
      if (!roomCode || msg.code !== roomCode) return;
      game = msg; stateAt = performance.now();
      onState();
    } else if (msg.type === 'event') {
      notify(msg.text, msg.eventType === 'wrong' || msg.eventType === 'tag', msg.eventType);
      if (msg.eventType === 'correct') chirp(740, 950);
      if (msg.eventType === 'wrong' || msg.eventType === 'tag') chirp(240, 140);
      if (msg.eventType === 'powerup') chirp(570, 1120);
      if (msg.eventType === 'reveal') chirp(840, 360);
    } else if (msg.type === 'left') resetToWelcome();
  });
  socket.addEventListener('close', () => {
    status('Host connection lost. Reconnecting…', true);
    setTimeout(connect, 1400);
  });
  socket.addEventListener('error', () => {});
}

function notify(text, wrong = false, kind = '') {
  ui.toast.textContent = text;
  ui.toast.classList.toggle('wrong', wrong);
  ui.toast.classList.toggle('reveal', kind === 'reveal');
  ui.toast.classList.remove('hidden');
  toastUntil = performance.now() + 2100;
  if (!game || game.phase === 'lobby' || game.phase === 'finished') {
    // The menu covers game toasts; show the error on its connection line too.
    if (wrong) status(text, false);
  }
}
function chirp(start, end) {
  if (!soundOn) return;
  try {
    audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator(), gain = audioContext.createGain();
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(start, audioContext.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(end, audioContext.currentTime + .12);
    gain.gain.setValueAtTime(.065, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(.001, audioContext.currentTime + .17);
    oscillator.connect(gain).connect(audioContext.destination);
    oscillator.start(); oscillator.stop(audioContext.currentTime + .18);
  } catch { /* Audio is optional. */ }
}

async function refreshMeta() {
  try { meta = await (await fetch('/api/meta')).json(); } catch { meta = {urls: []}; }
}
async function refreshRooms() {
  try { roomList = (await (await fetch('/api/rooms')).json()).rooms || []; renderRoomList(); } catch { /* reconnect handles this */ }
}
function renderRoomList() {
  const query = ui.searchInput.value.trim().toLowerCase();
  const matches = roomList.filter(r => `${r.name} ${r.code}`.toLowerCase().includes(query));
  ui.roomList.replaceChildren();
  if (!matches.length) {
    const p = document.createElement('p'); p.className = 'empty-list';
    p.textContent = 'No open rooms on this host. Create one to begin!';
    ui.roomList.append(p); return;
  }
  for (const room of matches) {
    const button = document.createElement('button'); button.className = 'room-option';
    const left = document.createElement('span'), title = document.createElement('strong'), subtitle = document.createElement('small'), right = document.createElement('b');
    title.textContent = room.name; subtitle.textContent = `Code ${room.code}`;
    right.textContent = `${room.players}/${room.maxPlayers} · JOIN →`;
    left.append(title, subtitle); button.append(left, right);
    button.addEventListener('click', () => joinRoom(room.code));
    ui.roomList.append(button);
  }
}

function rememberName() {
  const name = ui.nameInput.value.trim().slice(0, 18) || 'Player';
  localStorage.setItem('word-runners-name', name);
  return name;
}
function joinRoom(code) {
  if (!socket || socket.readyState !== WebSocket.OPEN) return;
  const normalized = code.toUpperCase().replace(/[^A-Z2-9]/g, '').slice(0, 5);
  if (normalized.length !== 5) { status('Enter the five-character room code.', false); return; }
  const remembered = JSON.parse(localStorage.getItem(`word-runners-session-${normalized}`) || 'null');
  send({type: 'join', code: normalized, name: rememberName(), token: remembered?.token});
}
ui.createBtn.addEventListener('click', () => send({type: 'create', name: rememberName()}));
ui.joinBtn.addEventListener('click', () => joinRoom(ui.codeInput.value));
ui.codeInput.addEventListener('keydown', e => { if (e.key === 'Enter') joinRoom(ui.codeInput.value); });
ui.searchInput.addEventListener('input', renderRoomList);
ui.nameInput.addEventListener('keydown', e => { if (e.key === 'Enter') ui.createBtn.click(); });

function resetToWelcome() {
  if (roomCode) localStorage.removeItem(`word-runners-session-${roomCode}`);
  roomCode = null; roomToken = null; playerId = null; game = null; lastLobbySignature = '';
  history.replaceState(null, '', location.pathname);
  for (const obj of playerMeshes.values()) scene.remove(obj.group);
  for (const obj of wordMeshes.values()) scene.remove(obj.group);
  for (const obj of powerupMeshes.values()) scene.remove(obj.group);
  playerMeshes.clear(); wordMeshes.clear(); powerupMeshes.clear();
  showPanel(ui.welcomePanel); refreshRooms();
}
for (const btn of [ui.leaveLobbyBtn, ui.leaveResultsBtn, ui.leaveGameBtn]) {
  btn.addEventListener('click', () => { send({type: 'leave'}); resetToWelcome(); });
}
ui.startBtn.addEventListener('click', () => send({type: 'start'}));
ui.againBtn.addEventListener('click', () => send({type: 'playAgain'}));
ui.cyclesSelect.addEventListener('change', () => send({type: 'settings', cycles: Number(ui.cyclesSelect.value)}));
ui.turnLengthSelect.addEventListener('change', () => send({type: 'settings', turnSeconds: Number(ui.turnLengthSelect.value)}));
ui.powerupFrequencySelect.addEventListener('change', () => send({type: 'settings', powerupFrequency: ui.powerupFrequencySelect.value}));
ui.soundBtn.addEventListener('click', () => {
  soundOn = !soundOn;
  ui.soundBtn.textContent = soundOn ? '♫' : '♪̸';
  ui.soundBtn.title = soundOn ? 'Mute sounds' : 'Enable sounds';
});

function inviteLink(base) { return `${base}/?room=${roomCode}`; }
function renderAddresses() {
  const all = location.protocol === 'https:'
    ? [location.origin]
    : [...new Set([...meta.urls, location.origin])];
  const lan = all.find(url => !/localhost|127\.0\.0\.1/.test(url));
  if (!chosenAddress || !all.includes(chosenAddress)) chosenAddress = lan || all[0];
  ui.addressList.replaceChildren();
  for (const url of all) {
    const button = document.createElement('button'); button.textContent = url;
    button.classList.toggle('active', url === chosenAddress);
    button.addEventListener('click', () => { chosenAddress = url; renderAddresses(); });
    ui.addressList.append(button);
  }
  QRCode.toDataURL(inviteLink(chosenAddress), {width:200, margin:1, color:{dark:'#102729', light:'#e5f2e0'}})
    .then(data => { ui.qrImage.src = data; }).catch(() => {});
}
async function copy(value) {
  try { await navigator.clipboard.writeText(value); notify('Copied to clipboard!'); }
  catch { window.prompt('Copy this address:', value); }
}
ui.copyCodeBtn.addEventListener('click', () => copy(roomCode));
ui.copyLinkBtn.addEventListener('click', () => copy(inviteLink(chosenAddress || location.origin)));

function renderLobby() {
  const isHost = game.hostId === playerId;
  ui.lobbyCode.textContent = game.code;
  ui.playerCount.textContent = `${game.players.filter(p => p.connected).length}/8`;
  ui.hostBadge.textContent = isHost ? 'YOU ARE THE HOST' : 'WAITING FOR HOST';
  ui.lobbyInstructions.textContent = location.protocol === 'https:'
    ? 'Everyone opens this same online game link. They can then enter the room code or find this room in the searchable list.'
    : 'Everyone opens the host PC’s address while connected to the same Wi-Fi. They can then enter the code or pick this room from the game list.';
  ui.hostSettings.classList.toggle('hidden', !isHost);
  ui.startBtn.classList.toggle('hidden', !isHost);
  ui.waitingText.classList.toggle('hidden', isHost);
  ui.startBtn.disabled = game.players.filter(p => p.connected).length < 2;
  ui.startBtn.firstChild.textContent = ui.startBtn.disabled ? 'WAITING FOR 2 PLAYERS ' : 'START THE CHASE ';
  ui.cyclesSelect.value = String(game.cycles);
  ui.turnLengthSelect.value = String(game.turnSeconds || 60);
  ui.powerupFrequencySelect.value = game.powerupFrequency || 'normal';
  ui.powerupHint.textContent = ({rare:'4 boosts · return after 12 seconds',normal:'7 boosts · return after 5.5 seconds',frequent:'12 boosts · return after 1.8 seconds'})[game.powerupFrequency || 'normal'];
  const connectedCount = game.players.filter(p => p.connected).length;
  const totalRounds = connectedCount * game.cycles;
  ui.roundSummary.textContent = `${connectedCount} ${connectedCount === 1 ? 'player' : 'players'} · ${totalRounds} total rounds · ${game.turnSeconds || 60} seconds per turn`;
  ui.lobbyPlayers.replaceChildren();
  for (const p of game.players) {
    const pill = document.createElement('div'); pill.className = `player-pill${p.connected ? '' : ' offline'}`;
    pill.textContent = p.name;
    const marker = document.createElement('span');
    marker.textContent = !p.connected ? 'OFFLINE' : p.id === game.hostId ? 'HOST' : p.id === playerId ? 'YOU' : 'READY';
    pill.append(marker); ui.lobbyPlayers.append(pill);
  }
  const signature = `${game.code}-${chosenAddress}`;
  if (lastLobbySignature !== signature) { lastLobbySignature = signature; renderAddresses(); }
}

function renderResults() {
  const ranking = [...game.players].sort((a, b) => b.points - a.points || b.tags - a.tags);
  ui.winnerTitle.replaceChildren(document.createTextNode(`${ranking[0]?.name || 'Forest'} wins the `));
  const em = document.createElement('em'); em.textContent = 'forest.'; ui.winnerTitle.append(em);
  ui.finalScores.replaceChildren();
  for (let i = 0; i < ranking.length; i++) {
    const p = ranking[i], row = document.createElement('div'); row.className = 'final-row';
    const place = document.createElement('strong'); place.textContent = `#${i + 1}`;
    const name = document.createElement('span'); name.textContent = p.name;
    const tags = document.createElement('small'); tags.textContent = `${p.tags} tags`; name.append(tags);
    const score = document.createElement('strong'); score.textContent = `${p.points} pts`;
    const stats = document.createElement('small'); stats.textContent = `${p.words} words · ${p.tags} tags`; name.append(stats);
    row.append(place, name, score); ui.finalScores.append(row);
  }
  const isHost = game.hostId === playerId;
  ui.againBtn.classList.toggle('hidden', !isHost);
  ui.againWait.classList.toggle('hidden', isHost);
}

function onState() {
  updateObjects();
  if (game.phase === 'lobby') { showPanel(ui.lobbyPanel); renderLobby(); }
  else if (game.phase === 'finished') { showPanel(ui.resultPanel); renderResults(); }
  else { showGame(); renderHUD(); }
}
function renderHUD() {
  const hunter = game.hunterId === playerId;
  ui.roundLabel.textContent = `ROUND ${game.round}/${game.totalRounds}`;
  ui.roleLabel.textContent = hunter ? 'HUNTER' : 'RUNNER';
  ui.roleLabel.style.color = hunter ? '#ff8c7c' : '#d8ff60';
  ui.ruleTitle.textContent = game.rule?.title ?? '';
  ui.ruleHint.textContent = game.rule?.hint ?? '';
  ui.objective.textContent = hunter
    ? 'Catch runners · tracking pulse every 10 seconds shows their direction and distance.'
    : 'Collect matching words · hide from the hunter’s 10-second tracking pulses.';
  ui.liveScores.replaceChildren();
  for (const p of [...game.players].sort((a, b) => b.points - a.points || b.tags - a.tags)) {
    const row = document.createElement('div'); row.className = `score-row${p.id === playerId ? ' you' : ''}${p.id === game.hunterId ? ' hunter' : ''}`;
    const dot = document.createElement('span'); dot.className = 'dot';
    const name = document.createElement('span'); name.textContent = `${p.name}${!p.connected ? ' (offline)' : ''}`;
    const score = document.createElement('b'); score.textContent = `${p.points} pt`; score.title = `${p.words} correct words · ${p.tags} tags`;
    row.append(dot, name, score); ui.liveScores.append(row);
  }
  renderRevealTracker();
}

function renderRevealTracker() {
  const reveal = game?.hunterId === playerId ? game.reveal : null;
  const targets = reveal?.targets || [];
  ui.revealTracker.classList.toggle('hidden', !reveal || !targets.length);
  if (!reveal || !targets.length) { ui.revealTargets.replaceChildren(); return; }
  ui.revealCountdown.textContent = `${Math.ceil(reveal.remainingMs / 1000)}s`;
  ui.revealTargets.replaceChildren();
  for (const target of targets) {
    const row = document.createElement('div'); row.className = 'reveal-row';
    const arrow = document.createElement('span'); arrow.className = 'reveal-arrow';
    arrow.textContent = '↑'; arrow.style.transform = `rotate(${target.bearingDeg}deg)`;
    arrow.setAttribute('aria-label', `Direction ${Math.round(target.bearingDeg)} degrees`);
    const name = document.createElement('span'); name.className = 'reveal-name'; name.textContent = target.name;
    const distance = document.createElement('b'); distance.textContent = `${Math.round(target.distance)} m`;
    row.append(arrow, name, distance); ui.revealTargets.append(row);
  }
}

// Everything in this scene is built from Three.js geometry and canvas textures;
// no fonts, images or CDNs are requested during a LAN game.
let renderer, scene, camera, sun;
const cameraBlockers = [];
const cameraRay = new THREE.Raycaster();
const clock = new THREE.Clock();
try {
  renderer = new THREE.WebGLRenderer({canvas: ui.gameCanvas, antialias: !matchMedia('(pointer: coarse)').matches, powerPreference: 'high-performance'});
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, matchMedia('(pointer: coarse)').matches ? 1.5 : 2));
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.38;
  scene = new THREE.Scene(); scene.background = new THREE.Color('#a9bea2');
  scene.fog = new THREE.FogExp2('#a9bea2', .0034);
  camera = new THREE.PerspectiveCamera(54, 1, .1, 360);
  camera.position.set(0, 38, 38);
  scene.add(new THREE.HemisphereLight('#d5e9d2', '#344c35', 2.2));
  sun = new THREE.DirectionalLight('#fff0cd', 3.0);
  sun.position.set(-30, 90, -45); sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.left = -90; sun.shadow.camera.right = 90;
  sun.shadow.camera.top = 90; sun.shadow.camera.bottom = -90;
  sun.shadow.camera.near = 1; sun.shadow.camera.far = 230;
  sun.shadow.bias = -.00025;
  scene.add(sun); scene.add(sun.target);
  buildForest();
  resize(); window.addEventListener('resize', resize);
  renderer.setAnimationLoop(frame);
} catch {
  status('This device needs WebGL to show the 3D forest.', true);
}

function box(w, h, d, color, x, y, z, parent = scene, material = null) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material || new THREE.MeshStandardMaterial({color, roughness:.88}));
  mesh.position.set(x, y, z); mesh.receiveShadow = true; mesh.castShadow = h > 1;
  parent.add(mesh); return mesh;
}
function textTexture(text, {bg = '#11273a', color = '#f5ffe5', border = '#a8d5d3', fontSize = 48, width = 400, height = 108} = {}) {
  const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
  const c = canvas.getContext('2d');
  c.fillStyle = bg; c.strokeStyle = border; c.lineWidth = 5;
  c.beginPath(); c.roundRect(5, 5, width - 10, height - 10, 18); c.fill(); c.stroke();
  c.fillStyle = color; c.font = `900 ${fontSize}px system-ui,sans-serif`;
  c.textAlign = 'center'; c.textBaseline = 'middle';
  c.fillText(text, width / 2, height / 2 + 2, width - 27);
  const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}
function label(text, w, h, options) {
  const texture = textTexture(text, options);
  const material = new THREE.SpriteMaterial({map: texture, transparent: true, depthTest: true});
  const sprite = new THREE.Sprite(material); sprite.scale.set(w, h, 1);
  sprite.userData.dispose = () => {texture.dispose(); material.dispose();};
  return sprite;
}

function forestHash(x, z, seed = 0) {
  const n = Math.sin(x * 127.1 + z * 311.7 + seed * 74.7) * 43758.5453;
  return n - Math.floor(n);
}
function addTrail(points, width, color) {
  const positions = [], indices = [];
  for (let i = 0; i < points.length; i++) {
    const before = points[Math.max(0, i - 1)], after = points[Math.min(points.length - 1, i + 1)];
    const dx = after.x - before.x, dz = after.z - before.z, length = Math.hypot(dx, dz) || 1;
    const nx = -dz / length, nz = dx / length, p = points[i];
    positions.push(p.x + nx * width, .035, p.z + nz * width, p.x - nx * width, .035, p.z - nz * width);
    if (i < points.length - 1) {
      const n = i * 2; indices.push(n, n + 1, n + 2, n + 1, n + 3, n + 2);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setIndex(indices); geometry.computeVertexNormals();
  const mesh = new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({color, roughness:1, side:THREE.DoubleSide}));
  mesh.receiveShadow = true; scene.add(mesh);
}
function buildForest() {
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(WORLD_HALF * 2, WORLD_HALF * 2),
    new THREE.MeshStandardMaterial({color:'#405b42', roughness:1}));
  ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);

  const eastWest = [], northSouth = [];
  for (let i = 0; i <= 220; i++) {
    const t = -WORLD_HALF + i * (WORLD_HALF * 2 / 220);
    eastWest.push(new THREE.Vector3(t, 0, 17 * Math.sin(t / 34)));
    northSouth.push(new THREE.Vector3(18 * Math.sin(t / 39), 0, t));
  }
  addTrail(eastWest, 4.7, '#927c56');
  addTrail(northSouth, 3.5, '#82724f');

  const hidePatchColors = ['#536444','#645d42','#62604a','#4b5e43','#536444'];
  for (const spot of HIDING_SPOTS) {
    const colorIndex = ['fern','log','boulder','pine','roots','hut'].indexOf(spot.kind) % hidePatchColors.length;
    const patch = new THREE.Mesh(new THREE.CircleGeometry(spot.radius * .78, 28),
      new THREE.MeshStandardMaterial({color:hidePatchColors[colorIndex], roughness:1}));
    patch.rotation.x = -Math.PI / 2; patch.position.set(spot.x,.045,spot.z); patch.receiveShadow = true; scene.add(patch);
  }

  const bark = new THREE.MeshStandardMaterial({color:'#ffffff', roughness:1});
  const foliage = new THREE.MeshStandardMaterial({color:'#ffffff', roughness:1});
  const greens = ['#31583b','#416946','#4e7449','#365c43'];
  const barkColors = ['#624832','#755338','#805c3d','#574331'];
  function instanced(items, geometry, material, transform, palette) {
    if (!items.length) return null;
    const mesh = new THREE.InstancedMesh(geometry, material, items.length), dummy = new THREE.Object3D();
    items.forEach((item, i) => {
      transform(dummy, item); dummy.updateMatrix(); mesh.setMatrixAt(i, dummy.matrix);
      if (palette) mesh.setColorAt(i, new THREE.Color(palette[item.shade % palette.length]));
    });
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    mesh.castShadow = true; mesh.receiveShadow = true; scene.add(mesh);
    return mesh;
  }
  instanced(ALL_TREES, new THREE.CylinderGeometry(.42,.62,1,7), bark, (o,t) => {
    o.position.set(t.x,t.height/2,t.z); o.scale.set(t.radius,t.height,t.radius);
  }, barkColors);

  const broadleaf = ALL_TREES.filter(t => t.kind !== 'pine');
  const pines = ALL_TREES.filter(t => t.kind === 'pine');
  instanced(broadleaf, new THREE.IcosahedronGeometry(1,1), foliage, (o,t) => {
    o.position.set(t.x,t.height*.72,t.z); o.scale.set(t.crownRadius,t.crownRadius*.78,t.crownRadius);
  }, greens);
  for (let layer = 0; layer < 2; layer++) {
    const factor = layer === 0 ? 1 : .72;
    instanced(pines, new THREE.ConeGeometry(1,1,8), foliage, (o,t) => {
      o.position.set(t.x,t.height*(layer === 0 ? .68 : .86),t.z);
      o.scale.set(t.crownRadius*factor,t.crownRadius*1.5*factor,t.crownRadius*factor);
    }, greens);
  }

  const bushes = instanced(SHRUBS, new THREE.IcosahedronGeometry(1,1), foliage, (o,b) => {
    o.position.set(b.x,b.height*.43,b.z); o.scale.set(b.crownRadius,b.height*.57,b.crownRadius);
  }, ['#294d34','#3a5d39','#496c40','#36543a']);

  instanced(HIDE_PROPS.filter(p => p.kind === 'boulder'), new THREE.DodecahedronGeometry(1,1),
    new THREE.MeshStandardMaterial({color:'#ffffff',roughness:1}), (o,p) => {
      o.position.set(p.x,p.height*.42,p.z); o.scale.set(p.radius,p.height*.62,p.radius*1.1);
      o.rotation.set(forestHash(p.x,p.z,31),forestHash(p.x,p.z,32)*Math.PI,forestHash(p.x,p.z,33));
    }, ['#66745a','#777b61','#6b765e','#85816a']);
  for (const prop of HIDE_PROPS) {
    if (prop.kind === 'hut') {
      const walls = box(prop.width,prop.height,prop.depth,'#786044',prop.x,prop.height/2,prop.z);
      const roof = new THREE.Mesh(new THREE.ConeGeometry(4.7,2.4,4),new THREE.MeshStandardMaterial({color:'#554432',roughness:1}));
      roof.position.set(prop.x,prop.height+1.05,prop.z); roof.rotation.y=Math.PI/4; roof.castShadow=true; scene.add(roof);
      const door = box(1.35,2.55,.12,'#493626',prop.x,1.28,prop.z+prop.depth/2+.05);
      const window = box(1.15,.85,.12,'#a7b78b',prop.x-1.55,2.65,prop.z+prop.depth/2+.06);
      cameraBlockers.push(walls,roof,door,window);
    } else if (prop.kind === 'log' || prop.kind === 'roots') {
      const log = new THREE.Mesh(new THREE.CylinderGeometry(prop.radius*.82,prop.radius,prop.length,10),
        new THREE.MeshStandardMaterial({color:prop.kind==='roots'?'#554a33':'#684a32',roughness:1}));
      log.position.set(prop.x,prop.height*.48,prop.z);
      log.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),new THREE.Vector3(Math.cos(prop.rotation),0,Math.sin(prop.rotation)));
      log.castShadow=true;log.receiveShadow=true;scene.add(log);cameraBlockers.push(log);
    }
  }

  // A carpet of small ground plants keeps the clearings and long trails readable.
  const groundPlants = [];
  for (let z = -144; z <= 144; z += 12) for (let x = -144; x <= 144; x += 12) {
    const px = x + (forestHash(x,z,21)-.5)*10, pz = z + (forestHash(x,z,22)-.5)*10;
    if (Math.abs(pz - 17*Math.sin(px/34)) < 7 || Math.abs(px - 18*Math.sin(pz/39)) < 6) continue;
    if (Math.abs(px) < 22 && Math.abs(pz) < 22) continue;
    if (HIDING_SPOTS.some(s => Math.hypot(px-s.x,pz-s.z)<s.radius*.65)) continue;
    if (forestHash(x,z,23) < .36) continue;
    groundPlants.push({x:px,z:pz,scale:.45+forestHash(x,z,24)*.6,shade:Math.floor(forestHash(x,z,25)*4)});
  }
  const plantMesh = instanced(groundPlants, new THREE.IcosahedronGeometry(.45,0),
    new THREE.MeshStandardMaterial({color:'#ffffff',roughness:1}), (o,g) => {
      o.position.set(g.x,.24,g.z); o.scale.set(g.scale*.8,g.scale,g.scale*.8);
    }, ['#71804b','#819255','#697b49','#89965a']);
  if (plantMesh) plantMesh.castShadow = false;

  // Low thickets keep the follow camera from passing straight through hideouts.
  if (bushes) cameraBlockers.push(bushes);
}
function makePlayer(p) {
  const group = new THREE.Group(); group.position.set(p.x,0,p.z);
  const hunter = p.id === game.hunterId;
  const coat = new THREE.MeshStandardMaterial({color:hunter?'#ff6d65':'#72d4e3',roughness:.65});
  const trim = new THREE.MeshStandardMaterial({color:hunter?'#b83c4c':'#23516e',roughness:.7});
  const face = new THREE.MeshStandardMaterial({color:'#ecc6a7',roughness:.88});
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(.67,1.1,4,10),coat); body.position.y=1.36;body.castShadow=true;group.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(.58,14,10),face);head.position.y=2.65;head.castShadow=true;group.add(head);
  const visor = box(.9,.16,.17,null,0,2.66,.52,group,trim);
  const leftLeg=box(.28,.77,.4,null,-.3,.42,0,group,trim);
  const rightLeg=box(.28,.77,.4,null,.3,.42,0,group,trim);
  const shieldAura=new THREE.Mesh(new THREE.TorusGeometry(1,.1,7,28),new THREE.MeshStandardMaterial({color:'#78dfff',emissive:'#2799d4',emissiveIntensity:1.1,transparent:true,opacity:.84}));
  shieldAura.rotation.x=-Math.PI/2;shieldAura.position.y=.2;group.add(shieldAura);
  const speedAura=new THREE.Mesh(new THREE.TorusGeometry(.76,.07,6,24),new THREE.MeshStandardMaterial({color:'#ffd36f',emissive:'#ff8a38',emissiveIntensity:1.1,transparent:true,opacity:.9}));
  speedAura.rotation.x=-Math.PI/2;speedAura.position.y=.27;group.add(speedAura);
  const nameLabel = label(p.name,Math.min(4.3,1.5+p.name.length*.18),.53,{width:360,height:75,fontSize:36,bg:hunter?'#692f39':'#193445',border:hunter?'#fca89f':'#8fd4dc'});
  nameLabel.position.y=3.72;group.add(nameLabel);
  scene.add(group);
  shieldAura.visible=false;speedAura.visible=false;
  return {group,body,coat,trim,visor,leftLeg,rightLeg,nameLabel,shieldAura,speedAura,target:new THREE.Vector3(p.x,0,p.z),hunter};
}
function makePickup(p) {
  const group = new THREE.Group(); group.position.set(p.x,0,p.z);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.3,.1,7,28),new THREE.MeshStandardMaterial({color:'#d4fba0',emissive:'#86a55c',emissiveIntensity:.7}));
  ring.rotation.x=-Math.PI/2;ring.position.y=.14;group.add(ring);
  const core = new THREE.Mesh(new THREE.OctahedronGeometry(.35,0),new THREE.MeshStandardMaterial({color:'#eafebd',emissive:'#d4ff76',emissiveIntensity:.8}));
  core.position.y=1.12;group.add(core);
  const wordLabel = label(p.word,Math.min(6.7,Math.max(3.6,2.1+p.word.length*.42)),1.42,{width:440,height:116,fontSize:52,bg:'#142a37',border:'#cae5c5'});
  wordLabel.position.y=2.45;group.add(wordLabel);
  scene.add(group);
  return {group,ring,core,wordLabel,word:p.word,target:new THREE.Vector3(p.x,0,p.z)};
}
function makePowerup(p) {
  const looks={
    speed:{color:'#ffd36f',emissive:'#d9822b',text:'SPEED'},
    shield:{color:'#83e6ff',emissive:'#2389c4',text:'SHIELD'},
    blink:{color:'#d6a5ff',emissive:'#904de3',text:'BLINK'}
  };
  const look=looks[p.type]||looks.speed,group=new THREE.Group();
  group.position.set(p.x,0,p.z);
  const material=new THREE.MeshStandardMaterial({color:look.color,emissive:look.emissive,emissiveIntensity:.8,metalness:.16,roughness:.32});
  const gem=p.type==='speed'?new THREE.OctahedronGeometry(.68,1):p.type==='shield'?new THREE.IcosahedronGeometry(.72,1):new THREE.TorusKnotGeometry(.43,.16,44,8,2,3);
  const core=new THREE.Mesh(gem,material);core.position.y=1.35;core.castShadow=true;group.add(core);
  const ring=new THREE.Mesh(new THREE.TorusGeometry(1.05,.1,7,24),new THREE.MeshStandardMaterial({color:look.color,emissive:look.emissive,emissiveIntensity:.75}));
  ring.rotation.x=-Math.PI/2;ring.position.y=.15;group.add(ring);
  const name=label(look.text,4.3,.96,{width:340,height:84,fontSize:41,bg:'#18283b',border:look.color});
  name.position.y=2.55;group.add(name);scene.add(group);
  return {group,core,ring,name,type:p.type};
}
function updateObjects() {
  if (!scene || !game) return;
  const visiblePlayers = new Set();
  for (const p of game.players) {
    visiblePlayers.add(p.id);
    if (!playerMeshes.has(p.id)) playerMeshes.set(p.id,makePlayer(p));
    const o=playerMeshes.get(p.id),hunter=p.id===game.hunterId;
    o.target.set(p.x,0,p.z);o.group.visible=p.connected;
    if (o.group.position.distanceTo(o.target)>17) o.group.position.copy(o.target);
    if (hunter!==o.hunter) {
      o.hunter=hunter;o.coat.color.set(hunter?'#ff6d65':'#72d4e3');
      o.trim.color.set(hunter?'#b83c4c':'#23516e');
    }
    o.shieldAura.visible=p.shielded;
    o.speedAura.visible=p.speedActive;
  }
  for (const [id,o] of playerMeshes) if (!visiblePlayers.has(id)) {scene.remove(o.group);o.nameLabel.userData.dispose();playerMeshes.delete(id);}
  const visibleWords=new Set();
  for (const p of game.pickups) {
    visibleWords.add(p.id);
    if (!wordMeshes.has(p.id)) wordMeshes.set(p.id,makePickup(p));
    const o=wordMeshes.get(p.id);
    if (o.word!==p.word) {
      o.group.remove(o.wordLabel);o.wordLabel.userData.dispose();o.word=p.word;
      o.wordLabel=label(p.word,Math.min(6.7,Math.max(3.6,2.1+p.word.length*.42)),1.42,{width:440,height:116,fontSize:52,bg:'#142a37',border:'#cae5c5'});
      o.wordLabel.position.y=2.45;o.group.add(o.wordLabel);
    }
    o.group.position.set(p.x,0,p.z);
  }
  for (const [id,o] of wordMeshes) if (!visibleWords.has(id)) {scene.remove(o.group);o.wordLabel.userData.dispose();wordMeshes.delete(id);}
  const visiblePowerups=new Set();
  for (const p of game.powerups||[]) {
    visiblePowerups.add(p.id);
    if (!powerupMeshes.has(p.id)) powerupMeshes.set(p.id,makePowerup(p));
    const o=powerupMeshes.get(p.id);o.group.position.set(p.x,0,p.z);
  }
  for (const [id,o] of powerupMeshes) if (!visiblePowerups.has(id)) {
    scene.remove(o.group);o.name.userData.dispose();o.core.geometry.dispose();o.core.material.dispose();o.ring.geometry.dispose();o.ring.material.dispose();powerupMeshes.delete(id);
  }
}

function resize() {
  if (!renderer) return;
  const w=innerWidth,h=innerHeight;
  renderer.setSize(w,h,false);camera.aspect=w/h;
  camera.fov=w/h<.7?59:54;camera.updateProjectionMatrix();
}
function frame() {
  const delta=Math.min(clock.getDelta(),.05),time=performance.now();
  for (const o of playerMeshes.values()) {
    o.group.position.lerp(o.target,1-Math.exp(-delta*16));
    const moving=o.group.position.distanceTo(o.target)>.1;
    o.body.rotation.z=moving?Math.sin(time*.016)*.06:0;
  }
  for (const [id,o] of wordMeshes) {
    o.wordLabel.position.y=2.45+Math.sin(time*.0025+id)*.22;
    o.ring.rotation.z=time*.00045+id;
    o.core.rotation.y=time*.001+id;
  }
  for (const [id,o] of powerupMeshes) {
    o.group.position.y=.18+Math.sin(time*.0027+id)*.18;
    o.core.rotation.x=time*.0008+id*.4;o.core.rotation.y=time*.0011+id;
    o.ring.rotation.z=time*.00055+id;
  }
  const own=playerMeshes.get(playerId);
  const focus=own&&game?.phase!=='lobby' ? own.group.position : new THREE.Vector3(Math.sin(time*.00015)*9,0,Math.cos(time*.00012)*6);
  const portrait=innerWidth/innerHeight<.8;
  const height=portrait?39:35,back=portrait?29:31;
  const desired=new THREE.Vector3(focus.x,height,focus.z+back);
  const eye=new THREE.Vector3(focus.x,1.7,focus.z);
  const ray=desired.clone().sub(eye),fullDistance=ray.length();
  cameraRay.set(eye,ray.normalize());cameraRay.far=fullDistance;
  const obstruction=cameraRay.intersectObjects(cameraBlockers,false)[0];
  if(obstruction){
    desired.copy(eye).addScaledVector(ray,Math.max(.45,obstruction.distance-.8));
    camera.position.copy(desired);
  }else camera.position.lerp(desired,1-Math.exp(-delta*3.8));
  camera.lookAt(focus.x,1.3,focus.z);
  if(game&&!ui.hud.classList.contains('hidden')){
    const remaining=Math.max(0,game.phaseRemainingMs-(time-stateAt));
    const sec=Math.ceil(remaining/1000);
    ui.timer.textContent=game.phase==='playing'?`${Math.floor(sec/60)}:${String(sec%60).padStart(2,'0')}`:String(sec);
    ui.timerLabel.textContent=game.phase==='playing'?'TIME LEFT':game.phase==='countdown'?'STARTS IN':'NEXT ROUND';
    if(game.phase==='countdown'){
      ui.phaseBanner.innerHTML=`${sec}<small>${game.hunterId===playerId?'YOU ARE THE HUNTER':'FIND THE MATCHING WORDS'}</small>`;
      ui.phaseBanner.classList.remove('hidden');
    }else if(game.phase==='intermission'){
      ui.phaseBanner.innerHTML=`ROUND COMPLETE<small>Next hunter in ${sec}…</small>`;
      ui.phaseBanner.classList.remove('hidden');
    }else ui.phaseBanner.classList.add('hidden');
    const me=game.players.find(p=>p.id===playerId);
    const dashLeft=Math.max(0,(me?.dashReadyInMs||0)-(time-stateAt));
    const hunter=game.hunterId===playerId;
    ui.dashCooldown.textContent=hunter?'UNLIMITED':dashLeft>0?`${Math.ceil(dashLeft/1000)}s`:'READY';
    ui.dashBtn.classList.toggle('cooldown',!hunter&&dashLeft>0);
    const boosts=[];
    if(me?.speedRemainingMs>0)boosts.push(`SPEED ${Math.ceil(Math.max(0,me.speedRemainingMs-(time-stateAt))/1000)}s`);
    if(me?.powerShieldRemainingMs>0)boosts.push(`SHIELD ${Math.ceil(Math.max(0,me.powerShieldRemainingMs-(time-stateAt))/1000)}s`);
    ui.boostStatus.textContent=boosts.length?`ACTIVE BOOSTS · ${boosts.join(' · ')}`:'';
    ui.boostStatus.classList.toggle('hidden',!boosts.length);
  }
  if(toastUntil&&time>toastUntil){ui.toast.classList.add('hidden');toastUntil=0;}
  renderer.render(scene,camera);
}

function inputVector(){
  let x=joystick.x,z=joystick.z;
  if(keys.has('a')||keys.has('arrowleft'))x--;
  if(keys.has('d')||keys.has('arrowright'))x++;
  if(keys.has('w')||keys.has('arrowup'))z--;
  if(keys.has('s')||keys.has('arrowdown'))z++;
  const length=Math.hypot(x,z);
  return {x:length>1?x/length:x,z:length>1?z/length:z,dash:dashHeld||keys.has(' ')};
}
setInterval(()=>{
  if(game?.phase==='playing'&&socket?.readyState===WebSocket.OPEN)send({type:'input',...inputVector()});
},50);
window.addEventListener('keydown',e=>{
  if(game?.phase!=='playing')return;
  const k=e.key.toLowerCase();
  if(['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright',' '].includes(k)){
    e.preventDefault();keys.add(k);
  }
});
window.addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));
window.addEventListener('blur',()=>{keys.clear();dashHeld=false;joystick.x=joystick.z=0;ui.stick.style.transform='';});
function updateStick(e){
  const r=ui.joystick.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
  let x=(e.clientX-cx)/38,z=(e.clientY-cy)/38;
  const length=Math.hypot(x,z);if(length>1){x/=length;z/=length;}
  joystick.x=x;joystick.z=z;
  ui.stick.style.transform=`translate(${x*38}px,${z*38}px)`;
}
ui.joystick.addEventListener('pointerdown',e=>{e.preventDefault();joystick.pointer=e.pointerId;ui.joystick.setPointerCapture(e.pointerId);updateStick(e);});
ui.joystick.addEventListener('pointermove',e=>{if(e.pointerId===joystick.pointer)updateStick(e);});
function releaseStick(e){if(e.pointerId!==joystick.pointer)return;joystick.pointer=null;joystick.x=joystick.z=0;ui.stick.style.transform='';}
ui.joystick.addEventListener('pointerup',releaseStick);
ui.joystick.addEventListener('pointercancel',releaseStick);
ui.dashBtn.addEventListener('pointerdown',e=>{e.preventDefault();dashHeld=true;ui.dashBtn.setPointerCapture(e.pointerId);});
ui.dashBtn.addEventListener('pointerup',()=>{dashHeld=false;});
ui.dashBtn.addEventListener('pointercancel',()=>{dashHeld=false;});

refreshMeta().then(()=>{if(game?.phase==='lobby')renderAddresses();});
refreshRooms();setInterval(()=>{if(!ui.welcomePanel.classList.contains('hidden'))refreshRooms();},3000);
connect();

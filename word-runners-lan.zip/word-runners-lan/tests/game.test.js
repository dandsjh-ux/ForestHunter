import test from 'node:test';
import assert from 'node:assert/strict';
import {createRoom, addPlayer, startMatch, tickRoom, setInput, snapshot, validateWordSets, ROUND_MS, COUNTDOWN_MS, BREAK_MS, REVEAL_INTERVAL_MS, REVEAL_DURATION_MS, POWERUP_FREQUENCIES} from '../game.js';
import {BLOCKERS, HIDING_SPOTS, SPAWNS, TREES, WORLD_HALF, canStand} from '../shared/map.js';
import {RULES} from '../shared/words.js';

test('all randomized Year Five word categories obey their displayed rules', () => {
  assert.equal(validateWordSets(), true);
  assert.equal(RULES.length, 13);
  assert.ok(RULES.every(rule => rule.words.length >= 15));
  const colours = RULES.find(rule => rule.id === 'colours');
  assert.ok(colours.words.includes('grey'));
  assert.ok(!colours.words.includes('gray'));
});

test('the wide forest has traversable trails, safe spawns and accessible hiding clearings', () => {
  assert.ok(WORLD_HALF >= 140);
  assert.ok(TREES.length > 180);
  assert.equal(HIDING_SPOTS.length, 8);
  assert.ok(SPAWNS.every(p => canStand(p.x, p.z)));
  assert.ok(HIDING_SPOTS.every(s => canStand(s.x, s.z)));
  assert.ok(BLOCKERS.every(b => !canStand(b.x, b.z, 0)));
});

test('turn settings control the exact round duration and rotate hunters evenly', () => {
  const {room, host} = createRoom('ABCDE', 'Host', 1000);
  const runner = addPlayer(room, 'Runner', 1000);
  room.cycles = 1;
  room.turnSeconds = 90;
  startMatch(room, 1000);
  assert.equal(snapshot(room, 1000).hunterId, host.id);
  assert.equal(room.phase, 'countdown');
  tickRoom(room, 1000 + COUNTDOWN_MS);
  assert.equal(room.phase, 'playing');
  assert.equal(snapshot(room, 1000 + COUNTDOWN_MS).phaseRemainingMs, 90_000);
  runner.words = 3; runner.points = 4;
  tickRoom(room, 1000 + COUNTDOWN_MS + 90_000);
  assert.equal(room.phase, 'intermission');
  tickRoom(room, 1000 + COUNTDOWN_MS + 90_000 + BREAK_MS);
  assert.equal(room.phase, 'countdown');
  assert.equal(snapshot(room).hunterId, runner.id);
  assert.equal(runner.words, 3);
  assert.equal(runner.points, 4);
  assert.equal(snapshot(room).totalRounds, 2);
});

test('target word category is randomized and cannot repeat on consecutive rounds', () => {
  const {room} = createRoom('ABCDE', 'Host', 1000);
  addPlayer(room, 'Runner', 1000);
  room.cycles = 4;
  room.turnSeconds = 30;
  startMatch(room, 1000);
  let previous = null;
  for (let i = 0; i < 6; i++) {
    assert.ok(RULES.some(rule => rule.id === room.rule.id));
    assert.notEqual(room.rule.id, previous);
    previous = room.rule.id;
    const roundStart = room.phaseEndsAt;
    tickRoom(room, roundStart);
    tickRoom(room, roundStart + room.turnSeconds * 1000);
    if (i < 5) tickRoom(room, roundStart + room.turnSeconds * 1000 + BREAK_MS);
  }
});

test('host validates correct pickups, wrong pickups and the two-point catch penalty', () => {
  const {room, host} = createRoom('ABCDE', 'Host', 1000);
  const runner = addPlayer(room, 'Runner', 1000);
  startMatch(room, 1000);
  tickRoom(room, 1000 + COUNTDOWN_MS);
  const now = 1000 + COUNTDOWN_MS + 50;
  const good = room.rule.words[0];
  room.pickups = [{id: 0, goodSlot: true, word: good, x: runner.x, z: runner.z}];
  tickRoom(room, now);
  assert.equal(runner.words, 1);
  assert.ok(room.events.some(e => e.type === 'correct' && e.playerId === runner.id));
  room.pickups = [{id: 0, goodSlot: false, word: 'garden', x: runner.x, z: runner.z}];
  tickRoom(room, now + 50);
  assert.equal(runner.words, 1);
  assert.equal(runner.points, 0);
  assert.ok(room.events.some(e => e.type === 'wrong'));
  room.pickups = [];
  runner.points = 1;
  runner.spawnShieldUntil = 0;
  host.x = runner.x; host.z = runner.z;
  tickRoom(room, now + 100);
  assert.equal(host.tags, 1);
  assert.equal(runner.points, -1);
  assert.ok(runner.spawnShieldUntil > now + 100);
});

test('hunter dash is unlimited while runners keep their cooldown', () => {
  const {room, host} = createRoom('ABCDE', 'Host', 1000);
  const runner = addPlayer(room, 'Runner', 1000);
  startMatch(room, 1000);
  tickRoom(room, 1000 + COUNTDOWN_MS);
  const now = 1000 + COUNTDOWN_MS + 50;
  setInput(host, {x:0,z:0,dash:true}, now);
  setInput(runner, {x:0,z:0,dash:true}, now);
  tickRoom(room, now);
  assert.equal(host.dashReadyAt, now);
  assert.equal(runner.dashReadyAt, now + 4600);
  const again = now + 1200;
  setInput(host, {x:0,z:0,dash:true}, again);
  setInput(runner, {x:0,z:0,dash:true}, again);
  tickRoom(room, again);
  assert.ok(host.dashUntil > again);
  assert.ok(runner.dashUntil <= again);
});

test('every ten-second tracking pulse warns players and gives only the hunter a three-second direction snapshot', () => {
  const {room, host} = createRoom('ABCDE', 'Hunter', 1000);
  const runner = addPlayer(room, 'Runner', 1000);
  const secondRunner = addPlayer(room, 'Second Runner', 1000);
  startMatch(room, 1000);
  const playingAt = 1000 + COUNTDOWN_MS;
  tickRoom(room, playingAt);
  host.x = 0; host.z = 0;
  runner.x = 3; runner.z = -4;
  secondRunner.x = -8; secondRunner.z = 0;

  tickRoom(room, playingAt + REVEAL_INTERVAL_MS - 1);
  assert.equal(room.events.some(event => event.type === 'reveal'), false);
  const pulseAt = playingAt + REVEAL_INTERVAL_MS;
  tickRoom(room, pulseAt);

  assert.equal(room.revealUntil, pulseAt + REVEAL_DURATION_MS);
  const reveal = snapshot(room, pulseAt, host.id).reveal;
  assert.equal(reveal.targets.length, 2);
  const target = reveal.targets.find(player => player.id === runner.id);
  assert.equal(target.name, 'Runner');
  assert.equal(target.distance, 5);
  assert.ok(Math.abs(target.bearingDeg - 36.87) < 0.1);
  assert.equal(snapshot(room, pulseAt, runner.id).reveal, null);
  assert.ok(room.events.some(event => event.type === 'reveal' && event.playerId === host.id));
  assert.ok(room.events.some(event => event.type === 'reveal' && event.playerId === runner.id));
  assert.ok(room.events.some(event => event.type === 'reveal' && event.playerId === secondRunner.id));
  assert.equal(snapshot(room, pulseAt + REVEAL_DURATION_MS + 1, host.id).reveal, null);

  tickRoom(room, playingAt + 2 * REVEAL_INTERVAL_MS);
  assert.equal(room.revealUntil, playingAt + 2 * REVEAL_INTERVAL_MS + REVEAL_DURATION_MS);
});

test('host powerup frequency changes the number of floating boosts', () => {
  for (const [frequency, profile] of Object.entries(POWERUP_FREQUENCIES)) {
    const {room} = createRoom('ABCDE', 'Host', 1000);
    addPlayer(room, 'Runner', 1000);
    room.powerupFrequency = frequency;
    startMatch(room, 1000);
    assert.equal(room.powerups.length, profile.count);
    assert.equal(snapshot(room).powerupFrequency, frequency);
  }
});

test('runner powerups grant speed, a shield or a safe teleport', () => {
  for (const type of ['speed', 'shield', 'blink']) {
    const {room, host} = createRoom('ABCDE', 'Host', 1000);
    const runner = addPlayer(room, 'Runner', 1000);
    startMatch(room, 1000);
    tickRoom(room, 1000 + COUNTDOWN_MS);
    const now = 1000 + COUNTDOWN_MS + 50;
    room.pickups = [];
    host.x = -135; host.z = -135;
    runner.spawnShieldUntil = 0;
    room.powerups = [{id:0,type,x:runner.x,z:runner.z,active:true,hiddenUntil:0}];
    const oldPosition = {x:runner.x,z:runner.z};
    tickRoom(room, now);
    assert.equal(room.powerups[0].active, false);
    assert.ok(room.events.some(e => e.type === 'powerup' && e.playerId === runner.id));
    if (type === 'speed') {
      assert.ok(runner.speedUntil >= now + 8000);
      const beforeX=runner.x;
      setInput(runner,{x:1,z:0,dash:false},now+50);
      tickRoom(room,now+50);
      assert.ok(runner.x-beforeX>.5);
    }
    if (type === 'shield') {
      assert.ok(runner.powerShieldUntil >= now + 6500);
      host.x=runner.x;host.z=runner.z;
      tickRoom(room,now+50);
      assert.equal(host.tags,0);
    }
    if (type === 'blink') {
      assert.ok(Math.hypot(runner.x - host.x, runner.z - host.z) >= 30);
      assert.ok(canStand(runner.x, runner.z));
      assert.notDeepEqual({x:runner.x,z:runner.z},oldPosition);
      host.x=runner.x;host.z=runner.z;
      tickRoom(room,now+50);
      assert.equal(host.tags,0);
    }
  }
});

test('tree trunks block movement on the host', () => {
  const {room} = createRoom('ABCDE', 'Host', 1000);
  const runner = addPlayer(room, 'Runner', 1000);
  startMatch(room, 1000);
  tickRoom(room, 1000 + COUNTDOWN_MS);
  const tree = TREES[0];
  runner.x = tree.x - tree.radius - 1.15;
  runner.z = tree.z;
  assert.ok(canStand(runner.x, runner.z));
  room.pickups = [];
  const now = 1000 + COUNTDOWN_MS + 100;
  setInput(runner, {x: 1, z: 0}, now);
  tickRoom(room, now);
  assert.ok(runner.x <= tree.x - tree.radius - 1.05);
});

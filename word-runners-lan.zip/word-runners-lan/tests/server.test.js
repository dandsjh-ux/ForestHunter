import test from 'node:test';
import assert from 'node:assert/strict';
import WebSocket from 'ws';
import {createAppServer} from '../server.js';

function waitFor(ws, predicate) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { ws.off('message', receive); reject(new Error('Timed out waiting for server')); }, 2000);
    function receive(raw) {
      const msg = JSON.parse(raw.toString());
      if (!predicate(msg)) return;
      clearTimeout(timer); ws.off('message', receive); resolve(msg);
    }
    ws.on('message', receive);
  });
}
async function connect(port) {
  const ws = new WebSocket(`ws://127.0.0.1:${port}/socket`);
  await new Promise((resolve, reject) => { ws.once('open', resolve); ws.once('error', reject); });
  return ws;
}
function say(ws, value) { ws.send(JSON.stringify(value)); }

test('two browser clients create, discover, join and start; guests cannot start', async () => {
  const app = createAppServer();
  const {port} = await app.listen(0);
  let host, guest;
  try {
    host = await connect(port);
    const joinedHost = waitFor(host, m => m.type === 'joined');
    say(host, {type:'create',name:'Teacher'});
    const {code} = await joinedHost;
    assert.match(code, /^[A-HJ-NP-Z2-9]{5}$/);
    const list = await (await fetch(`http://127.0.0.1:${port}/api/rooms`)).json();
    assert.equal(list.rooms[0].code, code);
    guest = await connect(port);
    const joinedGuest = waitFor(guest, m => m.type === 'joined');
    say(guest, {type:'join',code,name:'Student'});
    assert.equal((await joinedGuest).code, code);
    const denied = waitFor(guest, m => m.type === 'error');
    say(guest, {type:'start'});
    assert.match((await denied).message, /Only the host/);
    const configured = waitFor(host, m => m.type === 'state' && m.phase === 'lobby' && m.turnSeconds === 30);
    say(host, {type:'settings',turnSeconds:30});
    assert.equal((await configured).powerupFrequency, 'normal');
    const frequent = waitFor(host, m => m.type === 'state' && m.phase === 'lobby' && m.powerupFrequency === 'frequent');
    say(host, {type:'settings',powerupFrequency:'frequent'});
    assert.equal((await frequent).turnSeconds, 30);
    const moreRounds = waitFor(host, m => m.type === 'state' && m.phase === 'lobby' && m.cycles === 4);
    say(host, {type:'settings',cycles:4});
    await moreRounds;
    const guestDenied = waitFor(guest, m => m.type === 'error');
    say(guest, {type:'settings',cycles:4});
    assert.match((await guestDenied).message, /Only the host/);
    const started = waitFor(host, m => m.type === 'state' && m.phase === 'countdown');
    say(host, {type:'start'});
    const state = await started;
    assert.equal(state.players.length, 2);
    assert.equal(state.totalRounds, 8);
    assert.equal(state.turnSeconds, 30);
    assert.equal(state.powerupFrequency, 'frequent');
    assert.equal(state.powerups.length, 12);
    const powerupNotice = waitFor(guest, m => m.type === 'event' && m.eventType === 'powerup');
    app.rooms.get(code).events.push({type:'powerup',playerId:joinedGuest.playerId,text:'Speed boost!'});
    assert.equal((await powerupNotice).text, 'Speed boost!');
    const closed = await (await fetch(`http://127.0.0.1:${port}/api/rooms`)).json();
    assert.equal(closed.rooms.length, 0);
  } finally {
    await app.close();
  }
});

test('the server sends reveal data only to the hunter and warns every connected runner', async () => {
  const app = createAppServer();
  const {port} = await app.listen(0);
  let host, guest;
  try {
    host = await connect(port);
    const hostJoined = waitFor(host, m => m.type === 'joined');
    say(host, {type:'create',name:'Hunter'});
    const {code, playerId: hostId} = await hostJoined;

    guest = await connect(port);
    const guestJoined = waitFor(guest, m => m.type === 'joined');
    say(guest, {type:'join',code,name:'Runner'});
    const {playerId: guestId} = await guestJoined;
    const room = app.rooms.get(code);
    room.phase = 'playing';
    room.roundOrder = [hostId, guestId];
    room.roundIndex = 0;
    room.phaseEndsAt = Date.now() + 30_000;
    room.players.get(hostId).x = 0; room.players.get(hostId).z = 0;
    room.players.get(guestId).x = 3; room.players.get(guestId).z = -4;
    room.nextRevealAt = Date.now() + 25;

    const hunterState = waitFor(host, m => m.type === 'state' && m.phase === 'playing' && m.reveal?.targets?.length === 1);
    const runnerState = waitFor(guest, m => m.type === 'state' && m.phase === 'playing' && m.reveal === null);
    const hunterNotice = waitFor(host, m => m.type === 'event' && m.eventType === 'reveal');
    const runnerNotice = waitFor(guest, m => m.type === 'event' && m.eventType === 'reveal');
    const [hState, rState, hNotice, rNotice] = await Promise.all([hunterState, runnerState, hunterNotice, runnerNotice]);
    assert.equal(hState.reveal.targets[0].name, 'Runner');
    assert.equal(hState.reveal.targets[0].distance, 5);
    assert.equal(rState.reveal, null);
    assert.match(hNotice.text, /TRACKING PULSE/);
    assert.match(rNotice.text, /HUNTER PULSE/);
  } finally {
    guest?.close(); host?.close();
    await app.close();
  }
});

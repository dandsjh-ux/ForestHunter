# Word Runners: Forest Chase

A browser-based spelling chase for **2–8 players**, built with HTML5, Three.js and a small Node.js multiplayer server. It works on local Wi-Fi or through an online host. The 3D forest is built from bundled geometry, so players only need a modern browser; they do not need to install an app or create an account.

## Start a game

1. Extract the **whole ZIP** on the host computer. Install **Node.js 18 or newer** on that computer if it is not already installed.
2. On Windows, double-click **start-windows.bat**. On macOS/Linux, run `./start-mac-linux.command` from Terminal (or open the `.command` file). Keep the terminal window open.
3. On the host, open **http://localhost:3000**, enter a name, and select **Host a game**. If Windows asks about firewall access, allow Node.js on your **private** network.
4. Other players connect to the **same Wi-Fi**, then open the host's displayed Wi-Fi address on their phones, tablets or computers. The host can share the invitation link or QR code. Once the page is open, guests can enter the five-character room code or find the room in the searchable list.
5. When at least two players are in the lobby, the host chooses the match length, hunter turn duration and powerup frequency, then presses **Start the chase**.

**Important:** A room code alone cannot locate a computer across Wi-Fi. Guests must open the host PC's address or scan the QR invite first. The searchable list contains rooms running **on that host PC**. Choose an address such as `http://192.168.x.x:3000` or `http://10.x.x.x:3000`; `localhost` and `127.0.0.1` only work on the host itself. Some routers have *guest isolation* enabled, which prevents devices from reaching each other.

For local play, the host computer runs the server and the game stays on the local network. For online play, use the hosting steps below instead of the local Wi-Fi address.

## Online hosting with Render

The game uses Node.js and WebSockets, so deploy it as a **Web Service**, not a static site. The included `render.yaml` contains the recommended Render settings.

1. Extract the complete `word-runners-lan` folder. Keep `package.json`, `package-lock.json`, `server.js`, `game.js`, and the `client`, `public`, `shared` and `tests` folders together. Do not upload `node_modules`.
2. Create a **private** GitHub repository. Upload the contents of `word-runners-lan` so `package.json` sits at the repository root, then commit the files.
3. In Render, connect GitHub and choose **New → Blueprint**. Select this repository and the `main` branch. Render reads `render.yaml` and shows the service it will create; review it and deploy the Blueprint.
4. The Blueprint configures a Node web service in Singapore on the Free plan, with these commands:

   - Build: `npm install --include=dev && npm run build`
   - Start: `npm start`

5. When Render reports **Live**, copy its HTTPS address, such as `https://your-game-name.onrender.com`.
6. Open that address, host a room, and share the same HTTPS address with every player. They can join by room code or use the searchable room list. The lobby invite link and QR code use the public HTTPS address automatically.

If you create a **Web Service** manually instead, select Node, Singapore, and Free; leave **Root Directory** blank; then enter the same build and start commands shown above.

If Render's build log still runs `npm ci`, update the service's **Build Command** to `npm install --include=dev && npm run build` and redeploy. Make sure the service root contains `package.json` and `package-lock.json`; the lockfile is included in this package.

The GitHub repository can remain private; the deployed game address is public to anyone who has the link. Render's free web services sleep after 15 minutes without incoming traffic and may take about a minute to wake. This game stores rooms and scores in server memory, so a service restart or sleep ends the current lobby or match. Start a match after everyone has joined, and do not rely on the free plan for an always-available server.

## How to play

- The host can set each hunter's turn to **30, 45, 60, 90 or 120 seconds**. Choose **1–4 hunter turns per player**; turns rotate evenly, so the total round count adjusts to the number of players. A four-second countdown starts each turn.
- The forest is a wide **300 × 300** play area with winding trails, tree cover, thickets and eight clearings to duck into. Tree trunks and shrubs block movement on every device; the foliage also blocks the view, making it possible to break line of sight.
- A different Year Five word challenge is chosen at random every round, without repeating the previous category. Challenges include spelling patterns plus **colours, animals, woodland words, compound words, vowel starters, ough words and silent letters**.
- **Runners:** Move through the forest and touch floating words that fit the current challenge. A correct word adds one point; a mismatch removes one. Collect floating boosts for extra speed, a hunter-proof shield, or a blink teleport to a distant safe spot.
- **Powerup frequency:** Rare places 4 boosts and returns them after 12 seconds; Normal has 7 and a 5.5-second return; Frequent has 12 and a 1.8-second return. Each boost is one of the speed, shield or blink types.
- **Hunter:** Chase runners and catch them by getting close. Each catch removes **2 points** from that runner. They return to a safe spawn with a few seconds of protection.
- **Tracking pulse:** Every **10 seconds** during a hunter turn, the hunter sees a directional arrow and distance to each runner for **3 seconds**. Each runner gets an on-screen warning and sound when the pulse starts. The tracker points to the runners' last-known positions at the moment of the pulse.
- Points carry over between rounds. Highest points wins; hunter tags break a tie. Points can fall below zero. The final board also shows each runner's correct-word and hunter-tag totals.
- **Computer:** WASD or arrow keys to move; hold Space to dash. The hunter has no dash cooldown; runners do.
- **Phone/tablet:** Drag the on-screen joystick to move; tap and hold **Dash**. The hunter can keep dashing while Dash is held. Runners' dashes have a 4.6-second cooldown.
- Forest trails and clearings give players room to run; dense tree clusters and low thickets provide places to hide.

The randomized rounds use approximately Year Five vocabulary. Word categories include **Begins with S**, **Ends in -ing**, **Contains ea**, **Begins with un-**, **Ends in -ful**, **Double consonant**, **Colours**, **Animals**, **Woodland words**, **Starts with a vowel**, **Compound words**, **Contains ough**, and **Silent letter**.

## Troubleshooting

- **Other devices cannot open the page:** Check that they are on the same local network, use the host's Wi-Fi IP rather than `localhost`, and allow Node.js through the host computer's private-network firewall. If the host has several network addresses, try its Wi-Fi address.
- **Room code not found:** Confirm that the guest is on the correct host page, and that the host terminal window is still running.
- **Blank 3D view:** Enable hardware acceleration/WebGL in a modern browser such as Chrome, Edge, Firefox or Safari. A working WebGL browser is needed to play.
- **A player disconnects:** Reopen the same invitation link in the same browser. The client remembers its room token while the server runs. A match ends if fewer than two players remain connected for over 20 seconds.
- **Port 3000 is occupied:** Start from Terminal with `PORT=3001 node server.js` on macOS/Linux, or `set PORT=3001` followed by `node server.js` in Windows Command Prompt. Share the new address shown by the server.

## Edit and rebuild

The ZIP includes the source files. The bundled game and server work without running `npm install`; the host only needs Node.js. For code changes, install the development dependencies on a machine with Internet:

```sh
npm install
npm run build
npm test
npm start
```

Edit `shared/words.js` for word challenges, `shared/map.js` for the forest layout and collision, `client/main.js` for the 3D client, and `game.js` for the host's game rules. Rebuild after client/shared changes and restart the server after server/shared changes.

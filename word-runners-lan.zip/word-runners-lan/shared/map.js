// Shared by the host's collision checks and the Three.js scene.
export const WORLD_HALF = 150;

export const SPAWNS = [
  {x: 0, z: -14}, {x: 14, z: 0}, {x: 0, z: 14}, {x: -14, z: 0},
  {x: 10, z: -10}, {x: 10, z: 10}, {x: -10, z: 10}, {x: -10, z: -10}
];

export const HIDING_SPOTS = [
  {id: 'fern-hollow', name: 'Fern Hollow', x: -116, z: -103, radius: 12, kind: 'fern'},
  {id: 'fallen-oak', name: 'Fallen Oak', x: -42, z: -126, radius: 12, kind: 'log'},
  {id: 'mossy-boulders', name: 'Mossy Boulders', x: 45, z: -105, radius: 12, kind: 'boulder'},
  {id: 'pine-ring', name: 'Pine Ring', x: 116, z: -66, radius: 12, kind: 'pine'},
  {id: 'ranger-clearing', name: 'Ranger Clearing', x: -115, z: 18, radius: 12, kind: 'fern'},
  {id: 'root-tangle', name: 'Root Tangle', x: 113, z: 22, radius: 12, kind: 'roots'},
  {id: 'ranger-hut', name: 'Ranger Hut', x: -75, z: 105, radius: 12, kind: 'hut'},
  {id: 'stone-shelter', name: 'Stone Shelter', x: 63, z: 105, radius: 12, kind: 'boulder'}
];

export const HIDE_PROPS = [
  {id:'fallen-oak-log', kind:'log', x:-35.7, z:-119.7, length:12, radius:1.2, rotation:Math.PI*.75, height:2.4},
  {id:'ranger-cabin', kind:'hut', x:-69, z:111, width:5.5, depth:5, height:4.2},
  {id:'root-tangle', kind:'roots', x:119, z:28, length:10, radius:.8, rotation:Math.PI*.75, height:1.5},
  ...[2,7].flatMap(spotIndex => {
    const spot = HIDING_SPOTS[spotIndex];
    return Array.from({length:5}, (_,i) => {
      const angle = i * Math.PI * 2 / 5;
      return {id:`${spot.id}-rock-${i}`, kind:'boulder', shade:i%4,
        x:spot.x + Math.cos(angle)*8.7, z:spot.z + Math.sin(angle)*8.7,
        radius:1.25 + (i%2)*.25, height:2 + ((i*3)%4)*.4};
    });
  })
];

const hash = (x, z, seed = 0) => {
  const n = Math.sin(x * 127.1 + z * 311.7 + seed * 74.7) * 43758.5453;
  return n - Math.floor(n);
};
const inClearing = (x, z) => Math.abs(x) < 23 && Math.abs(z) < 23;
const nearTrail = (x, z) =>
  Math.abs(z - 17 * Math.sin(x / 34)) < 10 ||
  Math.abs(x - 18 * Math.sin(z / 39)) < 10;
const nearHidingSpot = (x, z, padding = 3) => HIDING_SPOTS.some(spot =>
  Math.hypot(x - spot.x, z - spot.z) < spot.radius + padding
);

// A reproducible, wide-spaced woodland grid leaves winding trails and clearings.
export const TREES = [];
for (let gz = -137; gz <= 137; gz += 16) {
  for (let gx = -137; gx <= 137; gx += 16) {
    const x = gx + (hash(gx, gz, 1) - .5) * 6;
    const z = gz + (hash(gx, gz, 2) - .5) * 6;
    if (inClearing(x, z) || nearTrail(x, z) || nearHidingSpot(x, z, 4)) continue;
    const variety = hash(gx, gz, 3);
    TREES.push({
      x, z, radius: .92 + variety * .18,
      height: 8 + hash(gx, gz, 4) * 4,
      crownRadius: 3.8 + hash(gx, gz, 5) * 1.7,
      kind: variety > .58 ? 'pine' : 'broadleaf',
      shade: Math.floor(hash(gx, gz, 6) * 4), hiding: false
    });
  }
}

// Each named hideout has a broken ring of trunks and a few low bushes inside.
// Gaps let runners slip in, while the layered foliage blocks the hunter's view.
export const HIDING_TREES = [];
export const HIDING_SHRUBS = [];
for (let s = 0; s < HIDING_SPOTS.length; s++) {
  const spot = HIDING_SPOTS[s];
  for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2 + Math.PI / 8;
    const radius = spot.radius * .76;
    HIDING_TREES.push({
      x: spot.x + Math.cos(angle) * radius,
      z: spot.z + Math.sin(angle) * radius,
      radius: 1.05, height: 10.5 + hash(s, i, 7) * 2,
      crownRadius: 4.8 + hash(s, i, 8) * .8,
      kind: spot.kind === 'pine' ? 'pine' : 'broadleaf',
      shade: (s + i) % 4, hiding: true
    });
  }
  for (let i = 0; i < 4; i++) {
    const angle = i * Math.PI / 2 + Math.PI / 4;
    HIDING_SHRUBS.push({
      x: spot.x + Math.cos(angle) * 4.9,
      z: spot.z + Math.sin(angle) * 4.9,
      radius: 1.3, height: 2.7 + hash(s, i, 9) * .5,
      crownRadius: 2.1, shade: (s + i) % 4, hiding: true
    });
  }
}

export const ALL_TREES = [...TREES, ...HIDING_TREES];

// Small thickets add texture but stay out of the main paths and clearings.
export const SHRUBS = [...HIDING_SHRUBS];
for (let gz = -126; gz <= 126; gz += 24) {
  for (let gx = -126; gx <= 126; gx += 24) {
    const x = gx + (hash(gx, gz, 10) - .5) * 11;
    const z = gz + (hash(gx, gz, 11) - .5) * 11;
    if (inClearing(x, z) || nearTrail(x, z) || nearHidingSpot(x, z, 15)) continue;
    if (hash(gx, gz, 12) < .39 || ALL_TREES.some(t => Math.hypot(t.x - x, t.z - z) < 7.5)) continue;
    const shade = Math.floor(hash(gx, gz, 13) * 4);
    SHRUBS.push({x, z, radius: 1.15, height: 2.5 + hash(gx, gz, 14), crownRadius: 1.8, shade, hiding: false});
  }
}

const naturalBlockers = [
  ...ALL_TREES.map(tree => ({x: tree.x, z: tree.z, radius: tree.radius, type: 'tree'})),
  ...SHRUBS.map(shrub => ({x: shrub.x, z: shrub.z, radius: shrub.radius, type: 'shrub'}))
];
const propBlockers = [];
for (const prop of HIDE_PROPS) {
  if (prop.kind === 'boulder') propBlockers.push({x:prop.x,z:prop.z,radius:prop.radius,type:prop.kind});
  if (prop.kind === 'log' || prop.kind === 'roots') {
    for (let along = -prop.length/2 + prop.radius; along <= prop.length/2 - prop.radius; along += prop.radius*1.35) {
      propBlockers.push({
        x:prop.x + Math.cos(prop.rotation)*along,
        z:prop.z + Math.sin(prop.rotation)*along,
        radius:prop.radius,type:prop.kind
      });
    }
  }
}
export const BLOCKERS = [...naturalBlockers, ...propBlockers];

export function canStand(x, z, radius = 1.05) {
  if (Math.abs(x) > WORLD_HALF - radius || Math.abs(z) > WORLD_HALF - radius) return false;
  if (BLOCKERS.some(b => Math.hypot(x - b.x, z - b.z) < b.radius + radius)) return false;
  return !HIDE_PROPS.some(p => p.kind === 'hut' &&
    Math.abs(x - p.x) < p.width / 2 + radius && Math.abs(z - p.z) < p.depth / 2 + radius);
}

const SILENT_LETTER_WORDS = new Set([
  'knight', 'knot', 'knee', 'knock', 'wrist', 'wrong', 'write', 'wrote',
  'whistle', 'listen', 'castle', 'island', 'honest', 'hour', 'gnaw', 'sign',
  'thumb', 'lamb', 'comb', 'autumn', 'calm', 'half', 'receipt', 'doubt'
]);
const COMPOUND_WORDS = new Set([
  'sunlight', 'woodland', 'pinecone', 'campfire', 'footprint', 'wildflower',
  'blackberry', 'birdhouse', 'raincoat', 'toothbrush', 'afternoon', 'playground',
  'something', 'inside', 'cupcake', 'backpack', 'homework', 'starfish',
  'snowman', 'coastline', 'sunshine', 'bedroom', 'football', 'seashell'
]);
const COLOURS = new Set([
  'red', 'blue', 'green', 'yellow', 'orange', 'purple', 'pink', 'brown', 'black', 'white',
  'grey', 'gold', 'silver', 'violet', 'indigo', 'scarlet', 'crimson', 'maroon', 'turquoise',
  'beige', 'coral', 'lilac', 'navy', 'amber'
]);
const ANIMALS = new Set([
  'badger', 'fox', 'deer', 'squirrel', 'hedgehog', 'otter', 'rabbit', 'owl', 'robin',
  'woodpecker', 'weasel', 'stoat', 'hare', 'raven', 'mole', 'beaver', 'falcon',
  'dormouse', 'swan', 'kingfisher'
]);
const WOODLAND = new Set([
  'canopy', 'bramble', 'burrow', 'fern', 'moss', 'bark', 'branch', 'seedling', 'pinecone',
  'acorn', 'sapling', 'undergrowth', 'stream', 'meadow', 'mushroom', 'roots', 'shelter',
  'wildflower', 'woodland', 'pathway'
]);

export const RULES = [
  {
    id: 'starts-s', title: 'Begins with S', hint: 'Find words whose first letter is S.',
    match: w => /^s/i.test(w),
    words: ['sudden', 'signal', 'shelter', 'silver', 'solution', 'shimmer', 'silent', 'sensible', 'sturdy', 'sentence', 'shadow', 'survey', 'supply', 'surface', 'spark', 'squeeze', 'squirrel', 'stream']
  },
  {
    id: 'ends-ing', title: 'Ends in -ing', hint: 'Look carefully at the final three letters.',
    match: w => /ing$/i.test(w),
    words: ['exploring', 'whispering', 'gathering', 'climbing', 'wondering', 'slipping', 'shining', 'building', 'floating', 'thinking', 'searching', 'shivering', 'protecting', 'travelling', 'carrying', 'collecting', 'noticing', 'remembering']
  },
  {
    id: 'contains-ea', title: 'Contains ea', hint: 'The letters e and a must be together in that order.',
    match: w => /ea/i.test(w),
    words: ['beacon', 'meadow', 'treasure', 'season', 'reason', 'feather', 'weather', 'steady', 'gleaming', 'stream', 'dream', 'creature', 'teacher', 'peach', 'leather', 'eager', 'beneath', 'seaside']
  },
  {
    id: 'starts-un', title: 'Begins with un-', hint: 'The first two letters must be u and n.',
    match: w => /^un/i.test(w),
    words: ['unhappy', 'unfair', 'unknown', 'unsafe', 'untidy', 'unusual', 'uncover', 'unlock', 'unpack', 'unwell', 'unwise', 'unlike', 'unable', 'unhelpful', 'unlucky', 'unwanted', 'untie', 'unsteady']
  },
  {
    id: 'ends-ful', title: 'Ends in -ful', hint: 'Check the last three letters, not the meaning.',
    match: w => /ful$/i.test(w),
    words: ['careful', 'grateful', 'hopeful', 'peaceful', 'cheerful', 'playful', 'helpful', 'colourful', 'thoughtful', 'powerful', 'harmful', 'useful', 'faithful', 'fearful', 'beautiful', 'wonderful', 'successful', 'thankful']
  },
  {
    id: 'double-consonant', title: 'Double consonant', hint: 'Find two identical consonants side by side.',
    match: w => /([bcdfghjklmnpqrstvwxyz])\1/i.test(w),
    words: ['butter', 'running', 'puzzle', 'supper', 'better', 'yellow', 'rabbit', 'dinner', 'happy', 'address', 'bottle', 'cotton', 'bigger', 'collect', 'mirror', 'sudden', 'middle', 'lesson']
  },
  {
    id: 'colours', title: 'Colours', hint: 'Collect the names of colours, using British spelling.',
    match: w => COLOURS.has(w.toLowerCase()),
    words: ['red', 'blue', 'green', 'yellow', 'orange', 'purple', 'pink', 'brown', 'black', 'white', 'grey', 'gold', 'silver', 'violet', 'indigo', 'scarlet', 'crimson', 'maroon', 'turquoise', 'beige', 'coral', 'lilac', 'navy', 'amber']
  },
  {
    id: 'animals', title: 'Animals', hint: 'Look for animals that might live in or near a forest.',
    match: w => ANIMALS.has(w.toLowerCase()),
    words: ['badger', 'fox', 'deer', 'squirrel', 'hedgehog', 'otter', 'rabbit', 'owl', 'robin', 'woodpecker', 'weasel', 'stoat', 'hare', 'raven', 'mole', 'beaver', 'falcon', 'dormouse', 'swan', 'kingfisher']
  },
  {
    id: 'woodland', title: 'Woodland words', hint: 'Collect things you might find in a woodland.',
    match: w => WOODLAND.has(w.toLowerCase()),
    words: ['canopy', 'bramble', 'burrow', 'fern', 'moss', 'bark', 'branch', 'seedling', 'pinecone', 'acorn', 'sapling', 'undergrowth', 'stream', 'meadow', 'mushroom', 'roots', 'shelter', 'wildflower', 'woodland', 'pathway']
  },
  {
    id: 'starts-vowel', title: 'Starts with a vowel', hint: 'The first letter is A, E, I, O or U.',
    match: w => /^[aeiou]/i.test(w),
    words: ['acorn', 'amber', 'animal', 'answer', 'apple', 'eagle', 'early', 'echo', 'eager', 'elm', 'evening', 'igloo', 'insect', 'island', 'olive', 'orange', 'orchard', 'otter', 'umbrella', 'unusual']
  },
  {
    id: 'compound', title: 'Compound words', hint: 'Find words made by joining two smaller words.',
    match: w => COMPOUND_WORDS.has(w.toLowerCase()),
    words: ['sunlight', 'woodland', 'pinecone', 'campfire', 'footprint', 'wildflower', 'blackberry', 'birdhouse', 'raincoat', 'toothbrush', 'afternoon', 'playground', 'something', 'inside', 'cupcake', 'backpack', 'homework', 'starfish', 'snowman', 'coastline', 'sunshine', 'bedroom', 'football', 'seashell']
  },
  {
    id: 'contains-ough', title: 'Contains ough', hint: 'Find the tricky letter pattern o-u-g-h.',
    match: w => /ough/i.test(w),
    words: ['although', 'bought', 'brought', 'cough', 'dough', 'drought', 'enough', 'fought', 'plough', 'rough', 'thought', 'thorough', 'though', 'through', 'tough', 'ought', 'nought', 'sought']
  },
  {
    id: 'silent-letter', title: 'Silent letter', hint: 'Collect a word with a letter we do not say aloud.',
    match: w => SILENT_LETTER_WORDS.has(w.toLowerCase()),
    words: ['knight', 'knot', 'knee', 'knock', 'wrist', 'wrong', 'write', 'wrote', 'whistle', 'listen', 'castle', 'island', 'honest', 'hour', 'gnaw', 'sign', 'thumb', 'lamb', 'comb', 'autumn', 'calm', 'half', 'receipt', 'doubt']
  }
];

const OTHER_WORDS = [
  'garden', 'window', 'planet', 'bridge', 'castle', 'village', 'forest', 'animal', 'curious',
  'brave', 'family', 'journey', 'pencil', 'quiet', 'market', 'pocket', 'lantern', 'river',
  'basket', 'mountain', 'carpet', 'freedom', 'chapter', 'station', 'plastic', 'tunnel',
  'magnet', 'volcano', 'courage', 'journey', 'lantern', 'path', 'footpath', 'adventure',
  'sunlight', 'birdsong', 'whisper', 'carefully', 'discover', 'enormous', 'imagine', 'library',
  'remember', 'together', 'wonder', 'yesterday', 'promise', 'village', 'harvest', 'delight',
  'candle', 'puzzle', 'minute', 'notice', 'treasure', 'outside', 'journey', 'brilliant'
];

export function distractorsFor(rule) {
  return [...new Set([...OTHER_WORDS, ...RULES.flatMap(r => r.words)])]
    .filter(w => !rule.match(w) && !rule.words.includes(w));
}

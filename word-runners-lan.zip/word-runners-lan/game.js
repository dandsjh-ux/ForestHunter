import {randomBytes} from 'node:crypto';
import {BLOCKERS, HIDING_SPOTS, HIDE_PROPS, SPAWNS, WORLD_HALF, canStand} from './shared/map.js';
import {RULES, distractorsFor} from './shared/words.js';

export const MAX_PLAYERS = 8;
export const ROUND_MS = 60_000;
export const TURN_SECONDS = [30, 45, 60, 90, 120];
export const COUNTDOWN_MS = 4_000;
export const BREAK_MS = 6_000;
export const REVEAL_INTERVAL_MS = 10_000;
export const REVEAL_DURATION_MS = 3_000;
const PICKUP_COUNT = 28;
const POWERUP_TYPES = ['speed', 'shield', 'blink'];
export const POWERUP_FREQUENCIES = Object.freeze({
  rare: {count: 4, respawnMs: 12_000},
  normal: {count: 7, respawnMs: 5_500},
  frequent: {count: 12, respawnMs: 1_800}
});

const randomItem = items => items[Math.floor(Math.random() * items.length)];
const distSq = (a, b) => (a.x - b.x) ** 2 + (a.z - b.z) ** 2;
const id = () => randomBytes(9).toString('hex');

export function cleanName(value) {
  return String(value ?? '').replace(/[<>\x00-\x1f]/g, '').trim().slice(0, 18) || 'Player';
}

export function createRoom(code, name, now = Date.now()) {
  const room = {
    code, name: cleanName(name) + "'s game", hostId: null, players: new Map(),
    order: [], phase: 'lobby', phaseEndsAt: 0, cycles: 2,
    turnSeconds: 60, powerupFrequency: 'normal', roundOrder: [],
    roundIndex: -1, rule: null, pickups: [], powerups: [], lastTick: now, lastActivity: now,
    nextRevealAt: 0, revealUntil: 0, revealTargets: [],
    lowPlayersSince: 0, events: []
  };
  const host = addPlayer(room, name, now);
  room.hostId = host.id;
  return {room, host};
}

export function addPlayer(room, name, now = Date.now()) {
  if (room.phase !== 'lobby') throw new Error('This match has already started.');
  if (room.order.length >= MAX_PLAYERS) throw new Error('That room is full.');
  const player = {
    id: id(), token: randomBytes(24).toString('hex'), name: cleanName(name),
    connected: true, x: 0, z: 0, words: 0, points: 0, tags: 0,
    input: {x: 0, z: 0, dash: false}, inputAt: now,
    dashUntil: 0, dashReadyAt: 0, spawnShieldUntil: 0, powerShieldUntil: 0, speedUntil: 0
  };
  room.players.set(player.id, player);
  room.order.push(player.id);
  room.lastActivity = now;
  return player;
}

export function removeLobbyPlayer(room, playerId) {
  room.players.delete(playerId);
  room.order = room.order.filter(id => id !== playerId);
  if (room.hostId === playerId) room.hostId = room.order[0] ?? null;
}

function chooseSpawn(room, from) {
  return [...SPAWNS].sort((a, b) => distSq(b, from) - distSq(a, from))[0];
}

function positionPickup(room, exclude) {
  for (let attempt = 0; attempt < 280; attempt++) {
    const spot = {x: Math.round((Math.random() * 2 - 1) * (WORLD_HALF - 5)), z: Math.round((Math.random() * 2 - 1) * (WORLD_HALF - 5))};
    if (!canStand(spot.x, spot.z, 2.1)) continue;
    if ([...room.pickups, ...room.powerups].some(p => p !== exclude && p.active !== false && distSq(p, spot) < (attempt < 200 ? 55 : 20))) continue;
    if ([...room.players.values()].some(p => distSq(p, spot) < 35)) continue;
    return spot;
  }
  return {x: 0, z: 0};
}

function refillPickup(room, pickup) {
  const pool = pickup.goodSlot ? room.rule.words : distractorsFor(room.rule);
  const alternatives = pool.filter(w => w !== pickup.word);
  pickup.word = randomItem(alternatives.length ? alternatives : pool);
  Object.assign(pickup, positionPickup(room, pickup));
}

function beginRound(room, now) {
  room.roundIndex++;
  const availableRules = RULES.filter(rule => rule.id !== room.previousRuleId);
  room.rule = randomItem(availableRules.length ? availableRules : RULES);
  room.previousRuleId = room.rule.id;
  room.phase = 'countdown';
  room.phaseEndsAt = now + COUNTDOWN_MS;
  room.lastTick = now;
  room.nextRevealAt = 0;
  room.revealUntil = 0;
  room.revealTargets = [];
  room.pickups = [];
  room.powerups = [];
  const hunterId = room.roundOrder[room.roundIndex];
  let runnerIndex = 0;
  for (const playerId of room.order) {
    const p = room.players.get(playerId);
    if (!p) continue;
    const spawn = playerId === hunterId ? {x: 0, z: 0} : SPAWNS[runnerIndex++ % SPAWNS.length];
    p.x = spawn.x; p.z = spawn.z;
    p.input = {x: 0, z: 0, dash: false};
    p.dashUntil = 0; p.dashReadyAt = now;
    p.spawnShieldUntil = now + COUNTDOWN_MS + 2500;
    p.powerShieldUntil = 0; p.speedUntil = 0;
  }
  for (let n = 0; n < PICKUP_COUNT; n++) {
    const pickup = {id: n, goodSlot: n % 2 === 0, word: '', x: 0, z: 0};
    room.pickups.push(pickup);
    refillPickup(room, pickup);
  }
  for (let n = 0; n < POWERUP_FREQUENCIES[room.powerupFrequency].count; n++) {
    const powerup = {id: n, type: POWERUP_TYPES[n % POWERUP_TYPES.length], x: 0, z: 0, active: true, hiddenUntil: 0};
    room.powerups.push(powerup);
    Object.assign(powerup, positionPickup(room, powerup));
  }
  room.events.push({type: 'round', text: `Round ${room.roundIndex + 1}: ${room.rule.title}`});
}

export function startMatch(room, now = Date.now()) {
  if (room.phase !== 'lobby' && room.phase !== 'finished') throw new Error('A match is already running.');
  const connected = room.order.filter(playerId => room.players.get(playerId)?.connected);
  if (connected.length < 2) throw new Error('At least two players are needed.');
  room.order = connected;
  for (const [playerId] of room.players) if (!connected.includes(playerId)) room.players.delete(playerId);
  for (const p of room.players.values()) { p.words = 0; p.points = 0; p.tags = 0; }
  room.roundOrder = Array.from({length: room.cycles}, () => connected).flat();
  room.roundIndex = -1;
  room.previousRuleId = null;
  room.lowPlayersSince = 0;
  beginRound(room, now);
}

export function setInput(player, data, now = Date.now()) {
  const x = Number(data.x), z = Number(data.z);
  if (!Number.isFinite(x) || !Number.isFinite(z)) return;
  const mag = Math.hypot(x, z);
  player.input = {x: mag > 1 ? x / mag : x, z: mag > 1 ? z / mag : z, dash: data.dash === true};
  player.inputAt = now;
}

function movePlayer(room, p, now, dt) {
  if (!p.connected || now - p.inputAt > 500) return;
  const hunter = room.roundOrder[room.roundIndex] === p.id;
  if (p.input.dash && (hunter || now >= p.dashReadyAt)) {
    p.dashUntil = now + 1150;
    p.dashReadyAt = hunter ? now : now + 4600;
  }
  const speed = (hunter ? 9.1 : 7.7 * (p.speedUntil > now ? 1.48 : 1)) * (p.dashUntil > now ? 1.58 : 1);
  const nx = p.x + p.input.x * speed * dt;
  if (canStand(nx, p.z)) p.x = nx;
  const nz = p.z + p.input.z * speed * dt;
  if (canStand(p.x, nz)) p.z = nz;
}

function collectAndTag(room, now) {
  const hunter = room.players.get(room.roundOrder[room.roundIndex]);
  if (!hunter) return;
  for (const powerup of room.powerups) {
    if (!powerup.active && now >= powerup.hiddenUntil) {
      Object.assign(powerup, positionPickup(room, powerup));
      powerup.active = true;
      powerup.hiddenUntil = 0;
    }
  }
  for (const p of room.players.values()) {
    if (!p.connected || p === hunter) continue;
    if (hunter.connected && now >= p.spawnShieldUntil && now >= p.powerShieldUntil && distSq(hunter, p) < 6.25) {
      hunter.tags++;
      p.points -= 2;
      const spawn = chooseSpawn(room, hunter);
      p.x = spawn.x; p.z = spawn.z; p.spawnShieldUntil = now + 5500;
      room.events.push({type: 'tag', text: `${hunter.name} caught ${p.name}! ${p.name} loses 2 points.`});
      continue;
    }
    for (const powerup of room.powerups) {
      if (!powerup.active || distSq(p, powerup) >= 3.6) continue;
      powerup.active = false;
      powerup.hiddenUntil = now + POWERUP_FREQUENCIES[room.powerupFrequency].respawnMs;
      if (powerup.type === 'speed') {
        p.speedUntil = now + 8000;
        room.events.push({type: 'powerup', playerId: p.id, text: 'Speed boost! You are faster for 8 seconds.'});
      } else if (powerup.type === 'shield') {
        p.powerShieldUntil = now + 6500;
        room.events.push({type: 'powerup', playerId: p.id, text: 'Shield on! The hunter cannot catch you for 6 seconds.'});
      } else {
        const destination = positionAwayFromHunter(room, hunter);
        p.x = destination.x; p.z = destination.z;
        p.spawnShieldUntil = Math.max(p.spawnShieldUntil, now + 2000);
        room.events.push({type: 'powerup', playerId: p.id, text: 'Blink! You teleported away and have a brief shield.'});
      }
      break;
    }
    for (const pickup of room.pickups) {
      if (distSq(p, pickup) >= 3.6) continue;
      const correct = room.rule.match(pickup.word);
      p.words += correct ? 1 : 0;
      p.points += correct ? 1 : -1;
      room.events.push({type: correct ? 'correct' : 'wrong', playerId: p.id,
        text: correct ? `+1 ${pickup.word}` : `-1 ${pickup.word} does not fit!`});
      refillPickup(room, pickup);
      break;
    }
  }
}

function positionAwayFromHunter(room, hunter) {
  for (let attempt = 0; attempt < 220; attempt++) {
    const spot = {x: Math.round((Math.random() * 2 - 1) * (WORLD_HALF - 6)), z: Math.round((Math.random() * 2 - 1) * (WORLD_HALF - 6))};
    if (!canStand(spot.x, spot.z, 2.1) || distSq(spot, hunter) < 900) continue;
    if (room.players.size > 2 && [...room.players.values()].some(p => p !== hunter && p.connected && distSq(p, spot) < 25)) continue;
    return spot;
  }
  return chooseSpawn(room, hunter);
}

export function tickRoom(room, now = Date.now()) {
  if (room.phase === 'lobby' || room.phase === 'finished') return;
  const connected = [...room.players.values()].filter(p => p.connected).length;
  if (connected < 2) {
    if (!room.lowPlayersSince) room.lowPlayersSince = now;
    if (now - room.lowPlayersSince > 20_000) {
      room.phase = 'finished'; room.phaseEndsAt = 0;
      room.events.push({type: 'notice', text: 'Match ended: too few players remained.'});
      return;
    }
  } else room.lowPlayersSince = 0;

  if (room.phase === 'countdown' && now >= room.phaseEndsAt) {
    room.phase = 'playing'; room.phaseEndsAt = now + room.turnSeconds * 1000;
    room.nextRevealAt = now + REVEAL_INTERVAL_MS;
    room.events.push({type: 'notice', text: 'Go! Find the matching words.'});
  } else if (room.phase === 'playing' && now >= room.phaseEndsAt) {
    if (room.roundIndex + 1 === room.roundOrder.length) {
      room.phase = 'finished'; room.phaseEndsAt = 0;
      room.events.push({type: 'notice', text: 'Match over! Check the final scores.'});
    } else {
      room.phase = 'intermission'; room.phaseEndsAt = now + BREAK_MS;
      room.events.push({type: 'notice', text: 'Round over. New hunter in a moment!'});
    }
  } else if (room.phase === 'intermission' && now >= room.phaseEndsAt) beginRound(room, now);

  const dt = Math.max(0, Math.min((now - room.lastTick) / 1000, 0.05));
  room.lastTick = now;
  if (room.phase !== 'playing') return;
  if (now >= room.nextRevealAt) {
    const hunter = room.players.get(room.roundOrder[room.roundIndex]);
    room.nextRevealAt = now + REVEAL_INTERVAL_MS;
    room.revealUntil = now + REVEAL_DURATION_MS;
    room.revealTargets = hunter ? [...room.players.values()]
      .filter(p => p.connected && p.id !== hunter.id)
      .map(p => {
        const dx = p.x - hunter.x, dz = p.z - hunter.z;
        return {
          id: p.id, name: p.name,
          bearingDeg: (Math.atan2(dx, -dz) * 180 / Math.PI + 360) % 360,
          distance: Math.hypot(dx, dz)
        };
      }) : [];
    if (hunter?.connected) {
      room.events.push({type: 'reveal', playerId: hunter.id, text: 'TRACKING PULSE! Runner arrows and distances are visible for 3 seconds.'});
      for (const target of room.revealTargets) {
        room.events.push({type: 'reveal', playerId: target.id, text: 'HUNTER PULSE! Your direction is revealed for 3s. Hide or move!'});
      }
    }
  }
  for (const p of room.players.values()) movePlayer(room, p, now, dt);
  collectAndTag(room, now);
}

export function snapshot(room, now = Date.now(), viewerId = null) {
  const isHunter = viewerId === room.roundOrder[room.roundIndex];
  return {
    type: 'state', code: room.code, name: room.name, hostId: room.hostId,
    phase: room.phase, phaseRemainingMs: Math.max(0, room.phaseEndsAt - now),
    cycles: room.cycles, turnSeconds: room.turnSeconds, powerupFrequency: room.powerupFrequency,
    round: room.roundIndex + 1, totalRounds: room.roundOrder.length,
    hunterId: room.roundOrder[room.roundIndex] ?? null,
    reveal: isHunter && now < room.revealUntil ? {
      remainingMs: room.revealUntil - now,
      targets: room.revealTargets.map(target => ({...target}))
    } : null,
    rule: room.rule ? {title: room.rule.title, hint: room.rule.hint} : null,
    players: room.order.map(playerId => {
      const p = room.players.get(playerId);
      return {id: p.id, name: p.name, connected: p.connected, x: p.x, z: p.z,
        words: p.words, points: p.points, tags: p.tags,
        shielded: now < p.spawnShieldUntil || now < p.powerShieldUntil,
        speedActive: now < p.speedUntil, speedRemainingMs: Math.max(0, p.speedUntil - now),
        powerShieldRemainingMs: Math.max(0, p.powerShieldUntil - now),
        dashing: now < p.dashUntil,
        dashReadyInMs: room.roundOrder[room.roundIndex] === p.id ? 0 : Math.max(0, p.dashReadyAt - now)};
    }),
    pickups: room.pickups.map(p => ({id: p.id, x: p.x, z: p.z, word: p.word})),
    powerups: room.powerups.filter(p => p.active).map(p => ({id: p.id, type: p.type, x: p.x, z: p.z}))
  };
}

export function validateWordSets() {
  for (const rule of RULES) {
    if (!rule.words.every(rule.match)) throw new Error(`Incorrect word in ${rule.id}`);
    if (distractorsFor(rule).some(rule.match)) throw new Error(`Incorrect distractor in ${rule.id}`);
  }
  if (BLOCKERS.some(b => canStand(b.x, b.z, 0))) throw new Error('Invalid forest collision');
  if (HIDE_PROPS.some(p => p.kind === 'hut' && canStand(p.x, p.z, 0))) throw new Error('A shelter is missing collision');
  if (HIDING_SPOTS.some(spot => !canStand(spot.x, spot.z, 0))) throw new Error('A hiding spot is blocked at its centre');
  return true;
}
